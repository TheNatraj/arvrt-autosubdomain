<?php
$servername = "localhost";
$username = "arvrt";
$password = "Arvrt@12345";
$dbname = "arvrt_db";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
/*
$servername = "95.111.234.149";
$username = "adbhutbh_userdata";
$password = "a@12345*@#1";
$dbname = "adbhutbh_users";
$conn = mysqli_connect($servername, $username, $password, $dbname);
*/
?>