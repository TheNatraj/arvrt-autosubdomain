<?php  session_start();
include("includes/db_config.php");?>
<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Adbhutbharat</title>
    <?php include("includes/css.php")?>
</head>
<?php if (isset($_SESSION['loggedin_admin']) && $_SESSION['loggedin_admin'] == true) { ?>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php")?>
		<?php include("includes/sidebar.php")?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border">
								<div class="col-md-12">
									<h3 class="box-title">Enquiry Details :</h3>
								</div>
							</div>

							<!-- /.box-header -->
							<div class="box-body">  
								<div class="table-responsive mt-20">
									<table class="table table-bordered table-striped example3">
										<thead>
											<tr>
												<th>S. No</th>
												<th>Category</th> 
												<th>Sub Category</th> 
												<th>Owner Name</th> 
												<th>Shop Name</th> 
												<th>Contact No.</th>
												<th>Email-Id</th>
												<th>Subject</th>
												<th>Message</th> 
												<th>Date</th> 
												<th>View</th>
												<th>Delete</th>
											</tr>
										</thead>
										<tbody>
											<?php  $sql="select * from enquiry";
											 $result= mysqli_query($conn, $sql);
											 $i=1;
											 while($res= mysqli_fetch_array($result)){
											 $idd=$res['category_id'];
											 $sql_qur=mysqli_query($conn, "select * from category where id='".$idd."'");
                                             $row_srv=mysqli_fetch_array($sql_qur);?>
											<tr>
												<td><?php echo $i; $i++; ?></td>
												<td><?php echo $row_srv['name']; ?></td> 
												<td><?php echo $res['sub_category']; ?></td> 
												<td><?php echo $res['name']; ?></td> 
												<td><?php echo $res['shop_name']; ?></td> 
												<td><?php echo $res['email']; ?></td> 
												<td><?php echo $res['phone']; ?></td> 
												<td><?php echo $res['subject']; ?></td> 
												<td><?php echo $res['message']; ?></td> 
												<td><?php echo $res['created_date']; ?></td> 
												 <td><a href="view-image.php?id=<?php echo $res['id']; ?>"><i class="fa fa-eye"></i></a></td> 
												<td><a href="javascript:delete_contact_by_ID('<?php echo $res['id'] ?>');" class="ask"><i class="fa fa-trash-o"></i></a></td>
											</tr>  
										    <?php } ?>
										</tbody>
									</table>
								</div>
								<!-- /.box-body -->
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body>
<?php } else { 
echo "<script>window.location.href='index.php'</script>";
} ?>
<script type="text/javascript">
	function delete_contact_by_ID(id)
{
	if (confirm('Do You Want to Deleting This \nContinue anyway?')) {
		window.location.href = 'delete_enquiry.php?id=' + id;
	}
}
</script>
</html>
