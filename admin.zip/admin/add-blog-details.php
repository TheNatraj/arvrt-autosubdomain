<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zeronot</title>
    <?php include("includes/css.php")?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php")?>
		<?php include("includes/sidebar.php")?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border"> 
									<h3 class="box-title">Add Blog Details</h3> 
							</div>
							<!-- /.box-header -->
							<div class="box-body">
								<form method="post" action="#">
									<div class="form-group"> 
										<div class="row col-md-12"> 
											<label class="col-md-2">Category Type:-</label>											
											<div class="col-md-10"> 
												<form>
													<label class="checkbox-inline mt-15">
													  <input type="checkbox" value="">Interiors
													</label>
													<label class="checkbox-inline mt-15">
													  <input type="checkbox" value="">Living Rooms
													</label>
													<label class="checkbox-inline mt-15">
													  <input type="checkbox" value=""> Bed Room
													</label>
													<label class="checkbox-inline mt-15">
													  <input type="checkbox" value=""> Wall Painting
													</label>
												</form>
											</div>
										</div>
										
										<div class="col-md-12">
											<label>Blog Title:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<textarea class="form-control" rows="2" placeholder="Enter Blog Title"></textarea>
											</div>
										</div> 
										<div class="col-md-6">
											<label>Blog Post By:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<input type="text" class="form-control" placeholder="Enter Blog Post By" value="">
											</div>
										</div> 
										
										<div class="col-md-6">
											<label>Blog Banner:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<input name="banner" type="file" class="form-control"/>
											</div>
										</div>
										<div class="col-md-6">
											<label>Blog Post Date:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<input type="date" class="form-control" placeholder="Enter Blog Date" value="">
											</div>
										</div> 
										
                                        <div class="col-md-6">
											<label>Blog Photo:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<input type="file" class="form-control" placeholder="Blog Photo">
											</div>  
										</div> 
										<div class="col-md-12">
											<label>Blog Description:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<textarea name="data" class="ckeditor"  style="height:200px"> </textarea>
											</div>
										</div> 
										<div class="clearfix"></div> 
										<div class="col-md-2">
											<input type="submit" class="btn btn-success btn-md btn-search mt-30" value="Add Blog Data">
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body>

</html>
