<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zeronot</title>
    <?php include("includes/css.php")?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php")?>
		<?php include("includes/sidebar.php")?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border">
								<div class="col-md-12">
									<h3 class="box-title">Blog Details :</h3>
								</div>
							</div>

							<!-- /.box-header -->
							<div class="box-body">  
								<div class="table-responsive mt-20">
									<table class="table table-bordered table-striped example1">
										<thead>
											<tr>
												<th>S. No</th>
												<th>Category</th> 
												<th>Blog Title</th> 
												<th>Blog Image</th> 
												<th>Post By</th>
												<th>Post Date</th> 
												<th>Description</th> 
												<th>Edit</th>  
												<th>Delete</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1.</td>
												<td>Interiors</td>
												<td>A compact view of the living + dining + kitchen in a single frame.</td>
												<td><img src="../assets/images/blog_img1.jpg" class="img-responsive" style="width:100px" alt=""> </td>
												<td>Admin </td>
												<td>14 May 2020 </td> 
												<td ><div style="height:100px; overflow:auto">Indian interiors are characteristic of dark wood stains being dominated by rose wood and teak wood for years. Indian interiors are characteristic of dark wood stains being dominated by rose wood and teak wood for years. Indian interiors are characteristic of dark wood stains being dominated by rose wood and teak wood for years. Indian interiors are characteristic of dark wood stains being dominated by rose wood and teak wood for years. Indian interiors are characteristic of dark wood stains being dominated by rose wood and teak wood for years. Indian interiors are characteristic of dark wood stains being dominated by rose wood and teak wood for years.</div> </td> 
												<td>
													<a href="edit-blog-details.php"><i class="fa fa-pencil"></i></a>
												</td>
												<td>
													<a href=""><i class="fa fa-trash-o"></i></a>
												</td>
											</tr>  
										</tbody>
									</table>
								</div>
								<!-- /.box-body -->
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body>

</html>
