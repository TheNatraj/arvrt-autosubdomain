<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zeronot</title>
    <?php include("includes/css.php")?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php")?>
		<?php include("includes/sidebar.php")?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header box-danger">
								<div class="col-md-12">
									<h3 class="box-title">Blog Subscriber Details :</h3>
								</div>
							</div>

							<!-- /.box-header -->
							<div class="box-body">  
								<div class="table-responsive mt-20">
									<table class="table table-bordered table-striped example1">
										<thead>
											<tr>
												<th>S. No</th>
												<th>Email</th>  
												<th>Delete</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1.</td>
												<td>abc@gmail.com</td> 
												<td>
													<a href=""><i class="fa fa-trash-o"></i></a>
												</td>
											</tr>  
											<tr>
												<td>2.</td>
												<td>pqr@gmail.com</td> 
												<td>
													<a href=""><i class="fa fa-trash-o"></i></a>
												</td>
											</tr>  
										</tbody>
									</table>
								</div>
								<!-- /.box-body -->
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body>

</html>
