<?php session_start();

  include("includes/db_config.php");
if (isset($_POST['submit'])) {
 //var_dump($_FILES);exit();
extract($_POST);
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d H:i:s');
    /*$tmp_file = $_FILES['cat_img']['tmp_name'];
    $ext = pathinfo($_FILES["cat_img"]["name"], PATHINFO_EXTENSION);
    $rand = md5(uniqid().rand());
    $cat_image = $rand.".".$ext;
    move_uploaded_file($tmp_file,"product/category/".$cat_image);

    $tmp_file = $_FILES['cat_banner_img']['tmp_name'];
    $ext = pathinfo($_FILES["cat_banner_img"]["name"], PATHINFO_EXTENSION);
    $rand = md5(uniqid().rand());
    $cat_bnimage = $rand.".".$ext;
    move_uploaded_file($tmp_file,"product/category/".$cat_bnimage);
*/
$ip=$_SERVER['REMOTE_ADDR'];
$sql="INSERT into category(name,ip_address,created_date) values ('$category','$ip','$date')";
//echo $sql; exit();
$res=mysqli_query($conn,$sql) or die(mysqli_error());
if($res)
{
 echo "<script>window.location.href='category.php'</script>";
}
}
if(isset($_POST['update']))
{
	//var_dump($_FILES);exit();
extract($_POST);
$id=$_POST["cat_id"];
$sql1 ="UPDATE  category  SET name='$cat_name'  WHERE id='$id'"; 
$res=mysqli_query($conn,$sql1) or die(mysqli_error());
if($res){
}
}

 ?>

<!DOCTYPE html>
<html lang="en-IN">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Zeronot</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<?php include("includes/css.php")?>
</head>
<?php if (isset($_SESSION['loggedin_admin']) && $_SESSION['loggedin_admin'] == true) { ?>

<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php")?>
		<?php include("includes/sidebar.php")?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-6">
						<div class="box box-danger">
							<div class="box-header with-border">
								<h3 class="box-title">Category</h3>
							</div>
							<!-- /.box-header -->
							<div class="box-body table-responsive">
								<table class="table table-bordered example2">
									<thead>
										<tr>
											<th>S. No</th>
											<th>Category</th>
											<th>Edit</th>
											<th>Delete</th>
										</tr>
									</thead>
									<tbody>
									<?php
									$sql="select * from category";
									$result = mysqli_query($conn, $sql);
									 $j=1;
									while($res= mysqli_fetch_array($result))
									{ 
									?>
										<tr>
											<td><?php echo $j; $j++; ?></td>
											<td><?php echo $res['name']; ?></td>
											<td><input type="button" name="edit" value="Edit" id="<?php echo $res["id"]; ?>" class="btn btn-md btn-success edit_data" /></td> 
											 <td><a href="javascript:delete_cat_by_ID('<?php echo $res['id'] ?>');" class="ask"><i class="fa fa-trash-o"></i></a></td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
							<!-- /.box-body -->
						</div>
					</div>
					<div class="col-md-6">
						<div class="box box-danger">
							<div class="box-header">
								<h3 class="box-title">Add New Category</h3>
							</div>
							<div class="box-body">
								<form method="post" action="" enctype="multipart/form-data">
									<div class="form-group">
										<label> Category :</label>
										<div class="input-group">
											<div class="input-group-addon">
												<i class="fa fa-suitcase"></i>
											</div>
											<input type="text" name="category" class="form-control" placeholder="Category">
										</div>
									</div>
								
									<div class="form-group">
										<div class="input-group">
											<input type="submit" name="submit" class="btn btn-success btn-md" value="Submit">
										</div>
									</div>
								</form>
							</div>
							<!-- /.box-body -->
						</div>
					</div>
				</div>
				<!-- Modal Category --> 
				<div id="add_data_Modal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Update Category</h4>  
                </div>  
                 <form method="post" id="insert_form" enctype="multipart/form-data">  
                <div class="modal-body">  
                    
                          <div class="form-group">
                          <label>Category</label>  
                          <input type="text" name="cat_name" id="cat_name" class="form-control" placeholder="Category Name">
                          </div>
                         <!-- <div class="form-group">
                         <label>Category Image</label>  
                          <input type="file" name="cat_img" class="form-control" placeholder=" Photo">
						 </div> 

                           <div class="form-group">
                         <label>Category Banner:<span class="text-red">Size : 950px X 100px</span</label>  
                          <input type="file" name="cat_banner_imag" class="form-control" placeholder=" Photo">
						 </div>  -->
                          <input type="hidden" name="cat_id" id="cat_id" /> 
                                    </div>  
                <div class="modal-footer">                  	 
                          <input type="submit" name="update" id="insert" value="Insert" class="btn btn-success" />  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div> 
                 </form>   
           </div>  
      </div>  
 </div>  
			<!-- ./Modal Category -->
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body>
<?php } else { 
echo "<script>window.location.href='index.php'</script>";
} ?>
<script language="javascript">
 $(document).ready(function(){ 
     
      $(document).on('click', '.edit_data', function(){  
           var cat_id = $(this).attr("id");  
           $.ajax({  
                url:"edit_category.php",  
                method:"POST",  
                data:{cat_id:cat_id},  
                dataType:"json",  
                success:function(data){  
                     $('#cat_name').val(data.name); 
                     $('#cat_id').val(data.id);  
                     $('#insert').val("Update");  
                     $('#add_data_Modal').modal('show');  
                }  
           });  
      });  
     
 });  

function delete_cat_by_ID(id)
{
	if (confirm('Do You Want to Deleting This \nContinue anyway?')) {
		window.location.href = 'delete_category.php?id=' + id;
	}
}
</script>
</html>