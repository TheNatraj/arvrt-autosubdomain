<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zeronot</title>
    <?php include("includes/css.php")?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php")?>
		<?php include("includes/sidebar.php")?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-6">
						<div class="box box-danger">
							<div class="box-header box-danger">
								<h3 class="box-title">Category</h3>
							</div> 
							<div class="box-body table-responsive">
								<table class="table table-bordered example1">
									<thead>
										<tr>
											<th>S.No</th>
											<th>Category</th>
											<th>Edit</th>
											<th>Delete</th>
										</tr>
									</thead>
									<tbody> 
										<tr>
											<td>1.</td>
											<td>Fashion/Garments</td> 
											<td><button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default"><i class="fa fa-pencil"></i> Edit</button></td> 
											 <td><a href="#" class="ask"><i class="fa fa-trash-o"></i></a></td>
										</tr> 
										<tr>
											<td>2.</td>
											<td>School</td> 
											<td><button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default"><i class="fa fa-pencil"></i> Edit</button></td> 
											 <td><a href="#" class="ask"><i class="fa fa-trash-o"></i></a></td>
										</tr> 
										<tr>
											<td>3.</td>
											<td>Medical Store</td> 
											<td><button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default"><i class="fa fa-pencil"></i> Edit</button></td> 
											 <td><a href="#" class="ask"><i class="fa fa-trash-o"></i></a></td>
										</tr> 
										<tr>
											<td>4.</td>
											<td>Kirana Store </td> 
											<td><button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default"><i class="fa fa-pencil"></i> Edit</button></td> 
											 <td><a href="#" class="ask"><i class="fa fa-trash-o"></i></a></td>
										</tr> 
										<tr>
											<td>5.</td>
											<td>Hospital</td>
											<td><button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default"><i class="fa fa-pencil"></i> Edit</button></td> 
											 <td><a href="#" class="ask"><i class="fa fa-trash-o"></i></a></td>
										</tr> 
									</tbody>
								</table>
							</div> 
						</div>
					</div>
					<div class="col-md-6">
						<div class="box box-danger">
							<div class="box-header">
								<h3 class="box-title">Add New Category</h3>
							</div>
							<div class="box-body">
								<form method="post" action="" enctype="multipart/form-data">
									<div class="form-group">
										<label> Category :</label>
										<div class="input-group">
											<div class="input-group-addon">
												<i class="fa fa-suitcase"></i>
											</div>
											<input type="text" name="category" class="form-control" placeholder="Category">
										</div>
									</div> 

									<div class="form-group">
										<div class="input-group">
											<input type="submit" name="submit" class="btn btn-success btn-md" value="Submit">
										</div>
									</div>
								</form>
							</div> 
						</div>
					</div>
				</div>
				<!-- Modal Category --> 
				<div id="modal-default" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Update Category</h4>  
                </div>  
                 <form method="post" enctype="multipart/form-data">  
                <div class="modal-body">                      
                          <div class="form-group">
                          <label>Category</label>  
                          <input type="text" name="cat_name" id="cat_name" class="form-control" placeholder="Category Name">
                          </div>                     
                </div>  
                <div class="modal-footer">  
                	 
                          <input type="submit" name="update" id="insert" value="Update" class="btn btn-success" />  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div> 
                 </form>   
           </div>  
      </div>  
 </div>  
			<!-- ./Modal Category -->
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body> 
</html>
