<?php session_start();
include("includes/db_config.php"); 
if (isset($_POST['submit'])) {
//	var_dump($_POST); exit();
extract($_POST);

if(empty($_POST['most_popular'])){
 $most_popular = 0;   
}
$sql="INSERT into plan_pricing(most_popular,blog_color,plan_name,duration,plan_price) values ('$most_popular','$blog_color','$planname','$duration','$plan_price')";

if  (mysqli_query($conn, $sql)) {
    $last_id= mysqli_insert_id($conn);
      if(($_POST["plan_text"]) > 0)  {
        for($i = 0; $i < count($_POST["plan_text"]); $i++){
        $plan_text = mysqli_real_escape_string($conn,$_POST['plan_text'][$i]);
        $sql_text="INSERT into plan_text(plan_id,plantext) values ('$last_id','$plan_text')";
        $spl_tx=mysqli_query($conn, $sql_text) or die(mysqli_error());
       }
    }	
}
if($spl_tx){
    echo "<script>window.location.href='package-detail.php'</script>";
}
} ?>
<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>Zeronot</title>
    <?php include("includes/css.php")?>
</head>
<style>
.cdy div{
width:48%;
float:left;
margin:10px;
}
hr{
    border:1px #e96125 solid!important;
}

</style>
<?php if (isset($_SESSION['loggedin_admin']) && $_SESSION['loggedin_admin'] == true) { ?>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php");?>
		<?php include("includes/sidebar.php");?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border"> 
									<h3 class="box-title">Add Package </h3> 
							</div>
							<!-- /.box-header -->
							<div class="box-body">
								<form method="post" action="">
									<div class="form-group"> 
										 <div class="col-md-2 col-xs-4">
											<div class="form-group">
												<label>Hote Package: </label>
												<div class="input-group"> 
													<input name="most_popular" value="1" type="checkbox">  
												</div>
											</div>
										</div> 
									
										</div>
										<div class="col-md-8">
												<label>Package Name:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="planname" type="text" placeholder="Package Name" class="form-control"/>
												</div>
											</div>   
										<div class="col-md-2 col-xs-4">
											<div class="form-group">
												<label>Choose Color: </label>
												<div class="input-group"> 
													<input type="color" name="blog_color" >
												</div>
											</div>
										</div> 
											
											<div class="col-md-4">
												<label> Package Price:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="plan_price" type="text" placeholder="Total Plan Price" class="form-control"/>
												</div>
											</div> 
											
											<div class="col-md-5">
												<label>Package Duration:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="duration" type="text" placeholder="Package Duration" class="form-control"/>
												</div>
											</div>  
											
										    <div id="dynamic_field">
											<div class="col-md-10">
												<label>Package Text:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="plan_text" type="text" placeholder="Plan Text Name" class="form-control"/>
												</div>
											</div>  
											<div class="col-md-2 mt-40 mb-10">
												<button type="button" name="add" id="add" class="btn btn-primary float-right"><i class="fa fa-plus"></i> Add More text</button>
											</div>
										    </div>
										    
										</div>
										</div>
										<div class="col-md-2">
											<input type="submit" name="submit" class="btn btn-success btn-md btn-search mt-30" value="Add Plan Data">
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body>
<?php } else { 
echo "<script>window.location.href='index.php'</script>";
} ?>
<script type="text/javascript">
$(document).ready(function() {
	var i = 1;
	$('#add_price').click(function() {
		i++;
		 $('#dynamic_price').append('<div id="row'+i+'" class="cdy"><div><strong>Plan Price </strong><br /><input type="text" name="plan_price[]" placeholder="Enter Plan Price" class="form-control name_list" /></div><div><strong>Plan Duration </strong><br /><input type="text" name="plan_duration[]" placeholder="Enter Plan Duration" class="form-control name_list" /></div><div style="width:10%; margin-top:30px"><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></div></div><div class="clearfix"></div><hr/>'); 
	});
	$(document).on('click', '.btn_remove', function() {
		var button_id = $(this).attr("id");
		$('#row' + button_id + '').remove();
	});
	$('#submit').click(function() {
		$.ajax({
			url: "add-plan-detail.php",
			method: "POST",
			data: $('#add_name').serialize(),
			success: function(data) {
				alert(data);
				$('#add_name')[0].reset();
			}
		});
	});
});

$(document).ready(function() {
	var j = 1;
	$('#add').click(function() {
		j++;
		 $('#dynamic_field').append('<div id="row'+j+'" class="cdy"><div><strong>Package Text </strong><br /><input type="text" name="plan_text[]" placeholder="Enter Package Text" class="form-control name_list" /></div><div style="width:10%; margin-top:30px"><button type="button" name="remove" id="'+j+'" class="btn btn-danger btn_remove">X</button></div></div><div class="clearfix"></div><hr/>'); 
	});
	$(document).on('click', '.btn_remove', function() {
		var button_id = $(this).attr("id");
		$('#row' + button_id + '').remove();
	});
	$('#submit').click(function() {
		$.ajax({
			url: "add-package-detail.php",
			method: "POST",
			data: $('#add_name').serialize(),
			success: function(data) {
				alert(data);
				$('#add_name')[0].reset();
			}
		});
	});
});


$(document).ready(function(){
$('#cat_id').on('change', function(){
    var cat_id = $(this).val();
    if(cat_id){
        $.ajax({
            type:'POST',
            url:'ajax_get_subcat.php',
            data:'cat_id='+cat_id,
            success:function(html){
                $('#sub_cat').html(html);
               // console.log(html);
               // $('#city').html('<option value="">Select Division</option>'); 
            }
        }); 
    }
 });
});
</script>
</html>
