<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zeronot</title>
    <?php include("includes/css.php")?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php")?>
		<?php include("includes/sidebar.php")?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border"> 
									<h3 class="box-title">Edit Services Details</h3> 
							</div>
							<!-- /.box-header -->
							<div class="box-body">
								<form method="post" action="#">
									<div class="form-group"> 										
										<div class="col-md-3">
											<label>Category:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<select class="form-control" placeholder="">
												<option>Select Category</option>
												<option>Web Design & Development</option> 
												<option>Digital Marketing</option> 
												</select>
											</div>
										</div>   										
										<div class="col-md-3">
											<label>Sub Category:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<select class="form-control" placeholder="">
												<option>Select Sub-Category</option>
												<option>Web Design</option> 
												<option>Digital Marketing</option> 
												</select>
											</div>
										</div>  
										<div class="col-md-6">
											<label>Banner:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div><img src="../img/web-development.jpg" style="width:80px; height:50px"><br/>
												<input name="banner" type="file" class="form-control"/>
											</div>
										</div> 
										 
										<div class="col-md-12">
											<label>Service Description:</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-suitcase"></i>
												</div>
												<textarea name="data" class="ckeditor"  style="height:200px"> </textarea>
											</div>
										</div> 
										<div class="clearfix"></div> <hr/ class="pt-0 pb-0">
										<div class="col-md-12">
											<h2 class="pt-0 pb-0">Add Features</h2>
											</div>
											<div class="col-md-6">
												<label>Features Name:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="featurename" type="text" placeholder="Features Name" class="form-control"/>
												</div>
											</div> 
											<div class="col-md-4">
												<label>Features Image:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div><img src="../img/logoname.png" style="width:50px; height:50px"><br/>
													<input name="banner" type="file" placeholder="Features Image" class="form-control"/>
												</div>
											</div>  
											<div class="col-md-2 mt-40 mb-10">
												<button type="submit" class="btn btn-primary float-right"><i class="fa fa-plus"></i> Add More Features</button>
											</div>
											<div class="clearfix"></div> <hr/ class="pt-0 pb-0">
										<div class="col-md-12">
											<h2 class="pt-0 pb-0">Add Plan Pricing</h2>
											</div>
											<div class="col-md-4">
												<label>Plan Number:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="plannumber" type="text" placeholder="Plan Number" class="form-control"/>
												</div>
											</div> 
											<div class="col-md-8">
												<label>Plan Name:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="planname" type="text" placeholder="Plan Name" class="form-control"/>
												</div>
											</div> 
											<div class="col-md-4">
												<label>Total Plan Price:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="planname" type="text" placeholder="Total Plan Price" class="form-control"/>
												</div>
											</div> 
											<div class="col-md-4">
												<label>Plan Price:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="planprice" type="text" placeholder="Plan Price" class="form-control"/>
												</div>
											</div> 
											<div class="col-md-4">
												<label>Registration Price:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="regprice" type="text" placeholder="Registration Price" class="form-control"/>
												</div>
											</div> 
											<div class="col-md-10">
												<label>Plan Text:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="featurename" type="text" placeholder="Features Name" class="form-control"/>
												</div>
											</div>  
											<div class="col-md-2 mt-40 mb-10">
												<button type="submit" class="btn btn-primary float-right"><i class="fa fa-plus"></i> Add More text</button>
											</div>
										</div>
										</div>
										<div class="col-md-2">
											<input type="submit" class="btn btn-success btn-md btn-search mt-30" value="Update Services Data">
										</div>
									</div>
								</form>
							</div>
						</div> 
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body>

</html>
