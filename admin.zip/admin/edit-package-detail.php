<?php session_start();
include("includes/db_config.php");
if(isset($_POST['update']))
{
	//var_dump($_POST);exit();
extract($_POST);
$id=$_GET["editid"];
$sql1 ="UPDATE  plan_pricing  SET plan_name='$plan_name', plan_price='$plan_price', duration='$duration' WHERE id='$id'"; 
$res=mysqli_query($conn,$sql1) or die(mysqli_error());
if($res){
echo "<script>window.location.href='package-detail.php'</script>";
}
}


?>
<!DOCTYPE html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zeronot</title>
    <?php include("includes/css.php")?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php")?>
		<?php include("includes/sidebar.php")?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border"> 
									<h3 class="box-title">Edit Package Details</h3> 
							</div>
							<!-- /.box-header -->
							<div class="box-body">
								<form method="post" action="">
									<div class="form-group"> 						<?php $id=$_GET['editid'];
									$sql="select plan_pricing.* from plan_pricing  where plan_pricing.id='".$id."'";
									$result = mysqli_query($conn, $sql); 
									$res= mysqli_fetch_array($result);?>
											<div class="clearfix"></div> 
										<div class="col-md-12">
											<h2 class="pt-0 pb-0">Package</h2>
											</div>
										
											<div class="col-md-8">
												<label>Package Name:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="planname" type="text" value="<?php echo $res['plan_name']; ?>" placeholder="Package Name" class="form-control"/>
												</div>
											</div> 
											
											<div class="col-md-4">
												<label>Package Price:</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="planprice" type="text" value="<?php echo $res['plan_price']; ?>" placeholder="Package Price" class="form-control"/>
												</div>
											</div> 
											<div class="col-md-4">
												<label>Duration :</label>
												<div class="input-group">
													<div class="input-group-addon">
														<i class="fa fa-suitcase"></i>
													</div>
													<input name="duration" type="text" value="<?php echo $res['duration']; ?>" placeholder=" Duration" class="form-control"/>
												</div>
											</div> 
											
										</div>
										<div class="col-md-2">
											<input type="submit" name="update" class="btn btn-success btn-md btn-search mt-30" value="Update  Data">
										</div>
										</div>
										
									</div>
								</form>
							</div>
						</div> 
			</section>
		</div>
		<?php include("includes/footer.php")?>
	</div>
	<?php include("includes/js.php")?>
</body>

</html>
