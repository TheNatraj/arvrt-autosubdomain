<!DOCTYPE html>
<html lang="zxx">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta name="author" content="" /> 
	<title>Company Name</title>
	<link rel="shortcut icon" href="img/favicon.png" /> 
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Dosis:300,400,600,700&amp;display=swap" rel="stylesheet"> 
	<link rel="stylesheet" href="css/plugins.css" /> 
	<link rel="stylesheet" href="css/style.css" />
</head>

<body>
	<!-- Start Navbar -->
	<nav class="navbar navbar-expand-lg">
		<div class="container">

			<!-- Logo -->
			<a class="logo" href="#">
				<img src="img/logo-light.png" alt="logo">
			</a>

			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="icon-bar"><i class="fas fa-bars"></i></span>
			</button>

			<!-- navbar links -->
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link active" href="#" data-scroll-nav="0">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#" data-scroll-nav="1">About</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#" data-scroll-nav="2">Products</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#" data-scroll-nav="3">Also Deal In</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#" data-scroll-nav="4">Our Team</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#" data-scroll-nav="5">Contact</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<!-- End Navbar -->

	<!-- Start Header -->
	<header class="header slider-fade" data-scroll-index="0">
		<div class="container-fluid">
			<div class="row">
				<div class="owl-carousel owl-theme full-width">
					<div class="text-center item bg-img" data-overlay-dark="7" data-background="img/s1.jpg">
						<div class="v-middle caption stwo mt-50">
							<div class="o-hidden">
								<h5>The Ultimate</h5>
								<h1>Creative Business</h1>
								<p>The Best Product Shop in Market.</p>

							</div>
						</div>
					</div>
					<div class="text-center item bg-img" data-overlay-dark="7" data-background="img/s2.jpg">
						<div class="v-middle caption stwo mt-50">
							<div class="o-hidden">
								<h5>The Ultimate</h5>
								<h1>Creative Business</h1>
								<p>The Best Product Shop in Market.</p>
							</div>
						</div>
					</div>
					<div class="text-center item bg-img" data-overlay-dark="7" data-background="img/s3.jpg">
						<div class="v-middle caption stwo mt-50">
							<div class="o-hidden">
								<h5>The Ultimate</h5>
								<h1>Creative Business</h1>
								<p>The Best Product Shop in Market.</p>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</header>

	<section class="hero section-padding" data-scroll-index="1">
		<div class="container">
			<div class="row">
				<div class="col-lg-7 col-md-7">
					<div class="intro text-center mb-80">
						<h6>Who AM I?</h6>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sagittis luctus lectus malesuada commodo. Maecenas id ligula euismod, placerat augue consequat, pharetra quam. Nam arcu eros, dignissim tempus mi id, sollicitudin consectetur est. Mauris euismod dolor ipsum, sit amet blandit nisl rhoncus at. Cras at lobortis dolor. Cras mollis, ipsum in sagittis tristique, elit augue luctus nisl, ac efficitur libero eros rhoncus tellus. Curabitur sed lorem lacus. Etiam convallis justo nulla, sit amet elementum risus pellentesque a. Nulla vehicula ipsum nec sapien elementum, laoreet pulvinar enim suscipit. Fusce faucibus justo odio, nec ornare odio tincidunt ultrices. Donec a posuere orci. Sed convallis est vel erat mattis ullamcorper. Praesent pharetra venenatis urna, ac.</p>
					</div>
				</div>

				<div class="feat-left col-lg-5">
					<div class="card ml-3">
						<img src="img/shopkeeper.jpg" class="card-img-top" alt="shop_keeper">
						<div class="card-body">
							<h5 class="card-title">Shop Keeper Name</h5>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section> 
	<section class="process">
		<div class="section-padding background bg-img parallaxie" data-overlay-dark="8" data-background="img/bg1.jpg">
			<div class="container">
				<div class="row">
					<div class="section-head col-lg-8 col-md-10 offset-md-1 offset-lg-2">
						<div class="row">
							<div class="col-lg-12 text-center">
								<h4>Also Deal In</h4>
							</div>
						</div>
					</div>
					<div class="col-lg-3 text-center">
						<div class="items">
							<div class="item-img">
								<img src="img/portfolio/4.jpg" alt="image">
								<h5><a href="enquiry-now.php"> Enquiry Now</a> </h5>
							</div>
						</div>
					</div>
					<div class="col-lg-3 text-center">
						<div class="items">
							<div class="item-img">
								<img src="img/portfolio/4.jpg" alt="image">
								<h5><a href="enquiry-now.php"> Enquiry Now</a> </h5>
							</div>
						</div>
					</div>
					<div class="col-lg-3 text-center">
						<div class="items">
							<div class="item-img">
								<img src="img/portfolio/4.jpg" alt="image">
								<h5><a href="enquiry-now.php"> Enquiry Now</a> </h5>
							</div>
						</div>
					</div>
					<div class="col-lg-3 text-center">
						<div class="items">
							<div class="item-img">
								<img src="img/portfolio/4.jpg" alt="image">
								<h5><a href="enquiry-now.php"> Enquiry Now</a> </h5>
							</div>
						</div>
					</div>
				</div>
			</div>
			</div>
	</section>

	<section class="portfolio section-padding" data-scroll-index="2">
		<div class="container">
			<div class="row"> 
				<div class="section-head col-lg-8 col-md-10 offset-md-1 offset-lg-2">
					<div class="row">
						<div class="col-lg-12 text-center">
							<h4>Our Works</h4>
						</div>
					</div>
				</div> 
				<div class="gallery full-width">
					<div class="items graphic">
						<div class="item-img">
							<img src="img/portfolio/1.jpg" alt="image">
							<div class="item-img-overlay">
								<div class="overlay-info full-width">
									<p>Logo | Branding</p>
									<h6><a href="enquiry-now.php"> Enquiry Now <span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span></a></h6>
								</div>
							</div>
						</div>
					</div>
					<div class="items web">
						<div class="item-img">
							<img src="img/portfolio/2.jpg" alt="image">
							<div class="item-img-overlay">
								<div class="overlay-info full-width">
									<p>Logo | Branding</p>
									<h6><a href="enquiry-now.php"> Enquiry Now <span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span></a></h6>
									<a href="img/portfolio/1.jpg" class="popimg">
										<span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span>
									</a>
								</div>
							</div>
						</div>
					</div>

					<!-- gallery item -->
					<div class="items brand">
						<div class="item-img">
							<img src="img/portfolio/3.jpg" alt="image">
							<div class="item-img-overlay">
								<div class="overlay-info full-width">
									<p>Logo | Branding</p>
									<h6><a href="enquiry-now.php"> Enquiry Now <span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span></a></h6>
									<a href="img/portfolio/1.jpg" class="popimg">
										<span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span>
									</a>
								</div>
							</div>
						</div>
					</div>

					<!-- gallery item -->
					<div class="items graphic">
						<div class="item-img">
							<img src="img/portfolio/4.jpg" alt="image">
							<div class="item-img-overlay">
								<div class="overlay-info full-width">
									<p>Logo | Branding</p>
									<h6><a href="enquiry-now.php"> Enquiry Now <span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span></a></h6> 
								</div>
							</div>
						</div>
					</div>

					<!-- gallery item -->
					<div class="items web">
						<div class="item-img">
							<img src="img/portfolio/5.jpg" alt="image">
							<div class="item-img-overlay">
								<div class="overlay-info full-width">
									<p>Logo | Branding</p>
									<h6><a href="enquiry-now.php"> Enquiry Now <span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span></a></h6> 
								</div>
							</div>
						</div>
					</div>

					<!-- gallery item -->
					<div class="items brand">
						<div class="item-img">
							<img src="img/portfolio/6.jpg" alt="image">
							<div class="item-img-overlay">
								<div class="overlay-info full-width">
									<p>Logo | Branding</p>
									<h6><a href="enquiry-now.php"> Enquiry Now <span class="icon"><i class="fas fa-long-arrow-alt-right"></i></span></a></h6> 
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="testimonials section-padding" data-overlay-dark="3" data-background="img/bg2.jpg">
		<div class="container">
			<div class="row">
				<div class="offset-lg-2 col-lg-8 offset-md-1 col-md-10">
					<div class="owl-carousel owl-theme text-center">
						<div class="item">
							<div class="client-area">
								<div class="img">
									<span class="icon"><img src="img/left-quote.svg" alt=""></span>
									<span class="icon"><img src="img/right-quote.svg" alt=""></span>
									<div class="author">
										<img src="img/clients/1.jpg" alt="">
									</div>
								</div>
								<h6>Alex Smith</h6>
								<span>Envato Customer</span>
							</div>
							<p>Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum
								velit class aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
						</div>
						<div class="item">
							<div class="client-area">
								<div class="img">
									<span class="icon"><img src="img/left-quote.svg" alt=""></span>
									<span class="icon"><img src="img/right-quote.svg" alt=""></span>
									<div class="author">
										<img src="img/clients/2.jpg" alt="">
									</div>
								</div>
								<h6>Sam Smith</h6>
								<span>Envato Customer</span>
							</div>
							<p>Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum
								velit class aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
						</div>
						<div class="item">
							<div class="client-area">
								<div class="img">
									<span class="icon"><img src="img/left-quote.svg" alt=""></span>
									<span class="icon"><img src="img/right-quote.svg" alt=""></span>
									<div class="author">
										<img src="img/clients/3.jpg" alt="">
									</div>
								</div>
								<h6>Alex Martin</h6>
								<span>Envato Customer</span>
							</div>
							<p>Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum
								velit class aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="team section-padding" data-scroll-index="4">
		<div class="container">
			<div class="row">
				<div class="section-head col-lg-12 col-md-12">
					<div class="row">
						<div class="col-lg-12 text-center">
							<h4>Our Team</h4>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>

				<div class="col-lg-3 col-md-6">
					<div class="item mb-md50">
						<div class="img">
							<img src="img/team/1.jpg" alt="">
						</div>
						<div class="info">
							<h6>Alex Smith</h6>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="item mb-md50">
						<div class="img">
							<img src="img/team/2.jpg" alt="">
						</div>
						<div class="info">
							<h6>Alex Smith</h6>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="item mb-sm50">
						<div class="img">
							<img src="img/team/3.jpg" alt="">
						</div>
						<div class="info">
							<h6>Alex Smith</h6>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="item">
						<div class="img">
							<img src="img/team/4.jpg" alt="">
						</div>
						<div class="info">
							<h6>Alex Smith</h6>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="contact section-padding bg-img" data-overlay-light="8" data-background="img/contact-map.jpg" data-scroll-index="5">
		<div class="container">
			<div class="row">
				<div class="section-head col-lg-8 col-md-10 offset-md-1 offset-lg-2">
					<div class="row">
						<div class="col-lg-5 text-right">
							<h6>Get In Touch</h6>
							<h4>Contact .</h4>
						</div>
						<div class="col-lg-6 offset-lg-1">
							<p>Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condime.
							</p>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-5">
					<div class="info mb-md50">
						<div class="item wow fadeIn" data-wow-delay=".3s">
							<h6>GET IN TOUCH</h6>
							<h3>Don’t Hesitate to contact with us for any information or inquiries</h3>
							<p><span>#101, Gumti Mohal, Auraiya</span> 650 live woshington - 908 new
								homepshire ave nw, Uttar Pradesh - 206122</p>
							<h4>+9109876543210</h4>
							<p><a href="#0">abc@gmail.com</a></p>
						</div>

						<div class="social">
							<a href="#0" class="icon">
								<i class="fab fa-facebook-f"></i>
							</a>
							<a href="#0" class="icon">
								<i class="fab fa-twitter"></i>
							</a>
							<a href="#0" class="icon">
								<i class="fab fa-linkedin-in"></i>
							</a>
							<a href="#0" class="icon">
								<i class="fab fa-behance"></i>
							</a>
							<a href="#0" class="icon">
								<i class="fab fa-instagram"></i>
							</a>
						</div> 
					</div>
				</div>

				<!-- Contact Form -->
				<div class="col-lg-7">
					<form class="form wow fadeIn" data-wow-delay=".5s" id="contact-form" method="post" action="#">

						<div class="messages"></div>

						<div class="controls">

							<div class="row">

								<div class="col-md-6">
									<div class="form-group">
										<input id="form_name" type="text" name="name" placeholder="Name *" required="required" data-error="Firstname is required.">
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<input id="form_email" type="email" name="email" placeholder="Email *" required="required" data-error="Valid email is required.">
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<input id="form_subject" type="text" name="subject" placeholder="Subject">
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<textarea id="form_message" name="message" placeholder="Your Message *" rows="4" required="required" data-error="Your message is required."></textarea>
										<div class="help-block with-errors"></div>
									</div>
								</div>

								<div class="col-md-12">
									<button type="submit" class="butn butn-bg"><span>Send Message <i class="icofont-paper-plane"></i></span></button>
								</div>

							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>
	<footer class="text-center">
		<div class="container">

			<div class="social">
				<a href="#0"><i class="icofont-facebook"></i></a>
				<a href="#0"><i class="icofont-twitter"></i></a>
				<a href="#0"><i class="icofont-instagram"></i></a>
				<a href="#0"><i class="icofont-linkedin"></i></a>
			</div>

			<p>&copy; 2021 Company Name All Rights Reserved | Design & Developed By : <a href="https://adbhutbharat.net/login.php" target="_blank">Adbhut Bharat</a></p>

		</div>
	</footer>
	<script src="js/jquery-3.0.0.min.js"></script>
	<script src="js/jquery-migrate-3.0.0.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/scrollIt.min.js"></script>
	<script src="js/jquery.hover3d.min.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.counterup.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/parallaxie.js"></script>
	<script src="js/isotope.pkgd.min.js"></script>
	<script src="js/YouTubePopUp.jquery.js"></script>
	<script src="js/validator.js"></script>
	<script src="js/scripts.js"></script>

</body>

</html>
