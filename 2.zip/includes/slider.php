<section class="owl-carousel owl-theme owl-loaded owl-drag scrollme">
    <div class="full h-100 sec-bg6">
      <div class="vc-parent">
        <div class="vc-child">
          <div class="top-banner">
            <div class="container animateme" data-when="exit" data-from="0" data-to="0.75" data-opacity="0" data-translatey="-100">
		
				<div class="row">
				<div class="col-lg-8 col-md-8">
							  <div class="row">
							  <div class="col-md-12 cd-filter">
        <form method="post" action="">
        <div class="container">  
            <div class="row" style="margin-top:20px;"> 
              <div class="col-md-5 pr-0">
                <div class="cd-filter-block">
                  <div class="cd-filter-content cd-select">
                    <select class="select-filter" name="category">
                      <option value="all">Select Category</option>
                      <?php
                      $sql_cat= mysqli_query($conn,"select * from category");
					  echo "<pre>";
					  print_r($sql_cat);
                      while($res_cat= mysqli_fetch_array($sql_cat))
                      { 
                      ?>
                      <option value="<?php echo $res_cat['id']; ?>"><?php echo $res_cat['name']; ?></option>
                    <?php } ?>
          
                    </select>
                  </div>
                </div>
              </div>
              <div class="col-md-5 pl-0 pr-0">
                <div class="cd-filter-block checkbox-group">
                  <input type="text" class="input" name="bname" data-ref="input-search" placeholder="Search your Business Name">
                </div>
              </div> 
              <div class="col-md-2 pl-0">  
                <input type="submit" value="Search" name="search" class="btn btn-default-yellow-fill search-btn">
              </div> 
              </div> 
            </div>
			</form>
          </div>	
        </div> 
        <?php if(isset($_POST['search']))
          { extract($_POST);
           date_default_timezone_set('Asia/Kolkata');
           $date = date('Y-m-d H:i:s');
           $sql_cats= mysqli_query($conn,"select * from category where id='".$category."'");
           $res_cats= mysqli_fetch_array($sql_cats);
           echo $category_name=$res_cats['name']; 
           echo $bname=$_POST['bname']; 
           $subdm=$bname.$category_name.".arvrt.in";
           $sql_sub = mysqli_query($conn,"SELECT * FROM user_profile WHERE subdomain_name = '".$subdm."'");
          if(mysqli_num_rows($sql_sub) == 0) {
          $res_subd= mysqli_fetch_array($sql_sub); 
          $sdomain=$res_subd['subdomain_name'];
          if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) { 
           //header("location:upload.php?subdm=".$res_subd['subdomain_name']);
            echo ("<script language='JavaScript'>
         window.location.href='upload.php?subdm=$subdm';
       </script>");
          } else {  echo "<script>window.location.href='login.php'</script>";  
        } } else {
          $res_subds= mysqli_fetch_array($sql_sub); //var_dump($res_subds); ?>
         <div class="heading" style="font-size:18px;line-height: 32px;"><?php echo $res_subds['subdomain_name']." Sub Domain alraedy Exists Please Choose Another Name"; ?><div class="animatype" style="font-size :18px;line-height: 27px;">
          <form method="post" action="upload.php">
            <?php  $subdmtw=$bname.$category_name."s.arvrt.in";
            $sql_subs = "SELECT * FROM user_profile WHERE subdomain_name = '".$subdmtw."'";
            $qry_ch=mysqli_query($conn,$sql_subs);
          if(mysqli_num_rows($qry_ch) == 0) {?>
            <label class="radio-inline">
            <input type="radio" value="<?= $subdmtw ?>" name="subdomains"><?= $subdmtw ?>
            </label><br/>
          <?php } ?>
           <?php  $subdmthr=$bname.$category_name."auraiya.arvrt.in";
            $sql_subth = "SELECT * FROM user_profile WHERE subdomain_name = '".$subdmthr."'";
            $qry_chthr=mysqli_query($conn,$sql_subth);
          if(mysqli_num_rows($qry_chthr) == 0) {?>
            <label class="radio-inline">
            <input type="radio" value="<?= $subdmthr ?>" name="subdomains"><?= $subdmthr ?>
            </label><br/>
          <?php } ?>
           <?php  $subdmfu=ucfirst($category_name.$bname.".arvrt.in");
            $sql_subth = "SELECT * FROM user_profile WHERE subdomain_name = '".$subdmfu."'";
            $qry_chthr=mysqli_query($conn,$sql_subth);
          if(mysqli_num_rows($qry_chthr) == 0) {?>
            <label class="radio-inline">
            <input type="radio" value="<?= $subdmfu ?>" name="subdomains"><?= $subdmfu ?>
            </label><br/>
          <?php } ?>
          <?php  $subdmfiv=ucfirst($category_name.$bname."auraiya.arvrt.in");
            $sql_subth = "SELECT * FROM user_profile WHERE subdomain_name = '".$subdmfiv."'";
            $qry_chthr=mysqli_query($conn,$sql_subth);
          if(mysqli_num_rows($qry_chthr) == 0) {?>
            <label class="radio-inline">
          <?php  $subdmfiv=ucfirst($category_name.$bname."auraiya.arvrt.in");?>
            <input type="radio" value="<?= $subdmtw ?>" name="subdomains"><?= $subdmfiv ?>
            </label><br/>
          <?php } ?>
          
           <input type="submit" value="Continue" name="subdms" class="btn btn-default-yellow-fill search-btn">
          </form>    
         </div></div><?php } } ?>
				<div class="heading animatype">Own Shop<div class="animatype" style="font-size :55px;"><span id="typed3"></span></div></div>
              <a href="#" class="btn btn-default-yellow-fill mr-3">Start For Free</a>
			 
              </div>  
				
			          <div class="col-lg-4 col-md-4">
	<div class="outerCircle"></div>
	<div class="innerCircle"></div>
	<a href="#"><div class="icon"> <button class="btn btn-success">GO</button></div></a>
</div>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>
	</section>