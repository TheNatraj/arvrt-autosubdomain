  <!-- ***** LOADING PAGE ****** -->
  <div id="spinner-area">
    <div class="spinner">
      <div class="double-bounce1"></div>
      <div class="double-bounce2"></div>
      <div class="spinner-txt">Aryavart</div>
    </div>
  </div>
  <!-- ***** UPLOADED MENU FROM HEADER.HTML ***** -->
  <header id="header"><!-- ***** NEWS ***** -->
  <div class="sec-bg3 p-2 pr-3 infonews">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6 news">
        <h6 class="m-0">
          <div class="badge feat bg-pink mr-2 left">news</div>
          <small class="text-light"><a class="c-yellow opa-8" href=""><i class="fas fa-arrow-circle-right"></i></a></small>
        </h6>
      </div>
      <div class="col-md-6 link">
        <li class="infonews-nav float-right">
          <a href="http://arvrt.in/">Aryavart</a>
          <a href="#"><b>+91 6395 996 304</b></a>
        </li>
      </div>
    </div>
  </div>
</div>
<!-- ***** NAV MENU ****** -->
<div class="menu-wrap">
  <div class="nav-menu">
    <div class="container">
      <div class="row">
        <div class="col-2 col-md-2">
          <a href="http://arvrt.in/">
           <img src="img/aryavart-logo.png" class="img-fluid">
	 
          </a>
        </div>
        <nav id="menu" class="col-10 col-md-10">
          <div class="navigation float-right">
            <button class="menu-toggle">
            <span class="icon"></span>
            <span class="icon"></span>
            <span class="icon"></span>
            </button>
            <ul class="main-menu nav navbar-nav navbar-right">
              <li class="menu-item menu-item-has-children">
                <a class="m-0 pr-1 v-stroke" href="index.php" data-i18n="[html]header.home">Home</a> 
              </li>
			  <li class="menu-item menu-item-has-children">
                <a class="m-0 pr-1 v-stroke" href="#" data-i18n="[html]header.support">Hosting</a>
                <div class="sub-menu megamenu">
                  <div class="container">
                    <div class="row">
                      <div class="service-list col-md-12">
                        <div class="row">
                          <div class="col-4 service">
                            <div class="media-left">
                              <img src="img/icon/1.png"/>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.knowlist">Un-Managed</a>
                              <p>Helping Hand as a friend</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <img src="img/icon/2.png"/>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.knowarticle">Semi-Managed</a>
                              <p>Dedicated support very close</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <img src="img/icon/3.png"/>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.contact">Managed</a>
                              <p>Inhand support as care of</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <img src="img/icon/4.png"/>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.legal">Fully-Managed</a>
                              <div class="badge inside bg-grey ml-1"></div>
                              <p>Dedicated support very close</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <img src="img/icon/5.png"/>
                            </div>
                            <div class="media-body">
                              <div>
                                <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.blog">S-Pannel(wordPress powered)</a>
                                <div class="badge inside bg-pink ml-1"></div>
                              </div>
                              <p>Wordpress is best</p>
                            </div>
                         </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <img src="img/icon/6.png"/>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.faq">Control Panel</a>
                              <p>Around 1 lac websites are running on c panel</p>
                            </div>
                          </div>
						  <div class="col-4 service">
                            <div class="media-left">
                              <img src="img/icon/7.png"/>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.faq">Plesk Powered</a>
                              <p>Around 3 lac websites running on c panel</p>
                            </div>
                          </div>
						  <div class="col-4 service">
                            <div class="media-left">
                              <img src="img/icon/1.png"/>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.faq">VPS Dedicated &nbsp;&nbsp;&nbsp;&nbsp;</a>
                              <p></p>
                            </div>
                          </div>
						  </div>
                      </div>
                      </div>
                  </div>
                </div>
              </li>
			  <li class="menu-item menu-item-has-children">
                <a class="m-0 pr-1 v-stroke" href="#" data-i18n="[html]header.services">Product</a>
                <div class="badge badge-pill bg-purple mr-4"></div>
                <div class="sub-menu menu-large">
                  <div class="service-list">
                    <div class="service">
                     
                      <div class="media-body">
                        <a class="menu-item" href="reseller" data-i18n="[html]submenu.reseller">Blog</a>
                        </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="dedicated" data-i18n="[html]submenu.dedicated">Website</a>
                        <p>But I must explain to you how all this</p>
                      </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="vps" data-i18n="[html]submenu.vps">Retail Store</a>
                        <p>At very Marginal Price</p>
                      </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="wordpress" data-i18n="[html]submenu.wordpress">Small & Medium Enterprises</a>
                        <p>On the other hand, we denounce with</p>
                      </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="domains" data-i18n="[html]submenu.domains">Commercial Association</a>
                        <p>Lorem ipsum dolor sit amet, consectetur</p>
                      </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="developer" data-i18n="[html]submenu.developer">Service Sector</a>
                        <p>ed ut perspiciatis unde omnis iste natus</p>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
				<li class="menu-item">
                <a class="m-0 pr-1 v-stroke" href="#" data-i18n="[html]header.pages">Pricing</a>
					<div class="badge badge-pill bg-purple mr-4"></div>
                <div class="sub-menu menu-large">
                  <div class="service-list">
                    <div class="service">
                     
                      <div class="media-body">
                        <a class="menu-item" href="reseller" data-i18n="[html]submenu.reseller">Online Pesence (Free)</a>
                        </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="dedicated" data-i18n="[html]submenu.dedicated">Features Pro (1 month trial)</a>
                    </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="vps" data-i18n="[html]submenu.vps">Premium-Platinum</a>
                    </div>
                    </div>
					  <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="vps" data-i18n="[html]submenu.vps">Enterprise-Diamond</a>
                        
                      </div>
                    </div>
                   </div>
                </div>
              </li>
              </li>
			  <li class="menu-item">
                <a class="m-0 pr-1 v-stroke" href="#" data-i18n="[html]header.pages">Feature Pro</a>
					<div class="badge badge-pill bg-purple mr-4"></div>
                <div class="sub-menu menu-large">
                  <div class="service-list">
                    <div class="service">
                     
                      <div class="media-body">
                        <a class="menu-item" href="reseller" data-i18n="[html]submenu.reseller">Sell On Selldome</a>
                        </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="dedicated" data-i18n="[html]submenu.dedicated">Sell On Fashion swarg</a>
                    </div>
                    </div>
                    <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="vps" data-i18n="[html]submenu.vps">Sell On Ration Pani</a>
                    </div>
                    </div>
					  <div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="vps" data-i18n="[html]submenu.vps">Sale On Facebook</a>
                    </div>
                    </div>
					<div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="vps" data-i18n="[html]submenu.vps">Sale On Instagram</a>
                    </div>
                    </div>
					<div class="service">
                    <div class="media-body">
                        <a class="menu-item" href="vps" data-i18n="[html]submenu.vps">Sale On Whatsapp</a>
                    </div>
                    </div>
                   </div>
                </div>
              </li>
              
			  <li class="menu-item">
                <a class="m-0 pr-1 v-stroke" href="enquiry.php" data-i18n="[html]header.features">Enquiry Now</a> 
              </li>
			  <!--
              <li class="menu-item">
                <a class="m-0 pr-1 v-stroke" href="#" data-i18n="[html]header.features">Contact Us</a> 
              </li>
              -->
              <li class="menu-item menu-item-has-children menu-last">
                <a class="v-stroke" href="#" data-i18n="[html]header.support">Suports</a>
                <div class="sub-menu megamenu">
                  <div class="container">
                    <div class="row">
                      <div class="service-list col-md-9">
                        <div class="row">
                          <div class="col-4 service">
                            <div class="media-left">
                              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg" src="fonts/svg/bookmark.svg" alt="Knowledgebase">
<title>bookmark</title>
<path fill="#5e686c" d="M29.031 12.094h-3.631c-0.231 0-0.419-0.188-0.419-0.419s0.188-0.419 0.419-0.419h3.206v-4.963h-3.206c-0.231 0-0.419-0.188-0.419-0.419s0.188-0.419 0.419-0.419h3.631c0.231 0 0.419 0.188 0.419 0.419v5.806c0 0.225-0.188 0.412-0.419 0.412z"></path>
<path fill="#5e686c" d="M29.031 12.094h-5.081c-0.231 0-0.419-0.188-0.419-0.419v-5.806c0-0.231 0.188-0.419 0.419-0.419h5.081c0.231 0 0.419 0.188 0.419 0.419v5.806c0 0.231-0.188 0.419-0.419 0.419zM24.375 11.25h4.238v-4.963h-4.238v4.963z"></path>
<path id="svg-ico" fill="#ee5586" d="M8.713 31.688h-5.806c-0.231 0-0.419-0.188-0.419-0.419v-30.481c0-0.231 0.188-0.419 0.419-0.419h5.806c0.231 0 0.419 0.188 0.419 0.419s-0.188 0.419-0.419 0.419h-5.381v29.631h5.381c0.231 0 0.419 0.188 0.419 0.419s-0.188 0.431-0.419 0.431z"></path>
<path fill="#5e686c" d="M22.5 31.688h-13.688c-0.231 0-0.419-0.188-0.419-0.419s0.188-0.419 0.419-0.419h13.688c1.369 0 2.481-1.119 2.481-2.488v-24.669c0-1.369-1.113-2.487-2.481-2.487h-13.65c-0.231 0-0.419-0.188-0.419-0.419s0.188-0.419 0.419-0.419h13.65c1.837 0 3.325 1.494 3.325 3.331v24.663c0 1.831-1.494 3.325-3.325 3.325z"></path>
<path fill="#5e686c" d="M22.5 31.688h-19.594c-0.231 0-0.419-0.188-0.419-0.419v-30.481c0-0.231 0.188-0.419 0.419-0.419h19.594c1.837 0 3.325 1.494 3.325 3.331v24.663c0 1.831-1.494 3.325-3.325 3.325zM3.331 30.844h19.169c1.369 0 2.481-1.119 2.481-2.488v-24.663c0-1.369-1.113-2.487-2.481-2.487h-19.169v29.637z"></path>
<path id="svg-ico" fill="#ee5586" d="M8.713 31.688c-0.231 0-0.419-0.188-0.419-0.419v-30.481c0-0.231 0.188-0.419 0.419-0.419s0.419 0.188 0.419 0.419v30.475c0.006 0.238-0.188 0.425-0.419 0.425z"></path>
<path fill="#5e686c" d="M19.6 8.419c-0.231 0-0.419-0.188-0.419-0.419v-4.219c0-0.231 0.188-0.419 0.419-0.419s0.419 0.188 0.419 0.419v4.219c0 0.231-0.188 0.419-0.419 0.419z"></path>
</svg>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.knowlist">Lista Knowlege</a>
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg" src="fonts/svg/book.svg" alt="Knowledgebase">
<title>book</title>
<path fill="#5e686c" d="M15.088 30.075c-0.219 0-0.444-0.050-0.669-0.144-0.519-0.238-1.981-0.844-2.706-0.919-1.019-0.1-2.494-0.156-4.394-0.156-2.638 0-5.181 0.1-5.206 0.106 0 0 0 0 0 0-1.137 0-1.969-0.837-1.969-1.913v-23.15c0-1.081 0.875-1.962 1.956-1.962h12.363c1.081 0 1.956 0.881 1.956 1.962v24.694c0 0.875-0.55 1.481-1.331 1.481zM7.319 28.025c1.925 0 3.431 0.056 4.475 0.156 1.012 0.1 2.881 0.944 2.956 0.981 0.113 0.044 0.225 0.069 0.331 0.069 0.444 0 0.494-0.444 0.494-0.637v-24.694c0-0.619-0.5-1.125-1.119-1.125h-12.356c-0.619 0-1.119 0.506-1.119 1.125v23.15c0 0.6 0.469 1.075 1.063 1.075 0.063 0 2.625-0.1 5.275-0.1z"></path>
<path id="svg-ico" fill="#ee5586" d="M16.906 30.069c-0.269 0-0.512-0.069-0.725-0.212-0.381-0.256-0.6-0.712-0.6-1.262h0.838c0 0.262 0.081 0.462 0.231 0.563s0.363 0.094 0.606-0.006c0.063-0.031 1.931-0.875 2.944-0.975 3.156-0.319 9.444-0.063 9.713-0.056 0.288 0.012 0.569-0.094 0.775-0.294s0.325-0.481 0.325-0.775v-23.15c0-0.619-0.5-1.125-1.119-1.125h-12.356c-0.619 0-1.119 0.506-1.119 1.125h-0.838c0-1.081 0.875-1.962 1.956-1.962h12.363c1.081 0 1.956 0.881 1.956 1.962v23.15c0 0.531-0.206 1.019-0.581 1.381-0.375 0.356-0.869 0.55-1.387 0.531-0.069 0-6.5-0.256-9.6 0.050-0.725 0.075-2.194 0.681-2.694 0.913-0.238 0.1-0.469 0.144-0.688 0.144z"></path>
</svg>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.knowarticle">Artigo Knowlege</a>
                              <p>Eaque ipsa quae ab illo inventore veritatis et quasi</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg" src="fonts/svg/emailopen.svg" alt="Knowledgebase">
<title>emailopen</title>
<path fill="#5e686c" d="M29.637 31.856h-27.244c-1.025 0-1.856-0.831-1.856-1.856v-17.925c0-1.019 0.831-1.856 1.856-1.856 0.237 0 0.425 0.188 0.425 0.425s-0.188 0.425-0.425 0.425c-0.556 0-1.006 0.45-1.006 1v17.931c0 0.556 0.45 1.006 1.006 1.006h27.244c0.556 0 1.006-0.45 1.006-1.006v-17.925c0-0.55-0.45-1-1.006-1-0.238 0-0.425-0.188-0.425-0.425s0.188-0.425 0.425-0.425c1.025 0 1.856 0.831 1.856 1.856v17.931c0 1.012-0.837 1.844-1.856 1.844z"></path>
<path fill="#5e686c" d="M1.681 31.144c-0.094 0-0.181-0.031-0.262-0.087-0.188-0.144-0.219-0.413-0.075-0.594l10.037-12.906c0.144-0.181 0.412-0.219 0.594-0.075 0.188 0.144 0.219 0.413 0.075 0.594l-10.037 12.906c-0.081 0.106-0.206 0.163-0.331 0.163z"></path>
<path fill="#5e686c" d="M30.35 31.144c-0.125 0-0.25-0.056-0.337-0.163l-10.031-12.906c-0.144-0.188-0.113-0.45 0.075-0.594 0.181-0.144 0.45-0.113 0.594 0.075l10.037 12.9c0.144 0.188 0.113 0.45-0.075 0.594-0.081 0.063-0.169 0.094-0.262 0.094z"></path>
<path id="svg-ico" fill="#ee5586" d="M16.012 21.106c-0.088 0-0.175-0.025-0.25-0.081l-13.619-10.037c-0.188-0.137-0.231-0.406-0.087-0.594 0.138-0.188 0.406-0.231 0.594-0.088l13.369 9.85 13.369-9.85c0.188-0.137 0.456-0.1 0.594 0.088s0.1 0.456-0.087 0.594l-13.625 10.037c-0.075 0.056-0.169 0.081-0.256 0.081z"></path>
<path id="svg-ico" fill="#ee5586" d="M29.631 11.075c-0.087 0-0.175-0.025-0.25-0.081l-13.369-9.856-13.363 9.85c-0.188 0.137-0.456 0.1-0.594-0.088s-0.1-0.456 0.087-0.594l13.619-10.037c0.15-0.112 0.356-0.112 0.506 0l13.619 10.037c0.188 0.137 0.231 0.406 0.087 0.594-0.081 0.113-0.212 0.175-0.344 0.175z"></path>
</svg>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.contact">Contacte-nos</a>
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg" src="fonts/svg/compare.svg" alt="Knowledgebase">
<title>compare</title>
<path fill="#5e686c" d="M20.131 6.181h7.225c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-7.225c-0.212-2.112-1.994-3.763-4.162-3.763-2.162 0-3.95 1.656-4.162 3.763h-7.219c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h7.225c0.213 2.112 1.994 3.763 4.162 3.763s3.95-1.65 4.156-3.763zM15.975 9.113c-1.844 0-3.344-1.5-3.344-3.344s1.5-3.344 3.344-3.344c1.844 0 3.344 1.5 3.344 3.344s-1.5 3.344-3.344 3.344z"></path>
<path id="svg-ico" fill="#ee5586" d="M14.875 23.081c-0.006-0.050-0.025-0.1-0.050-0.144l-6.881-12.488c-0.013-0.031-0.031-0.056-0.056-0.081 0 0 0 0 0 0-0.006-0.012-0.019-0.019-0.025-0.031 0 0 0 0 0 0-0.006-0.006-0.019-0.019-0.025-0.025 0 0 0 0-0.006 0-0.006-0.006-0.019-0.012-0.031-0.019 0 0 0 0-0.006 0-0.006-0.006-0.013-0.006-0.019-0.012-0.006 0-0.006-0.006-0.013-0.006 0 0 0 0 0 0-0.050-0.025-0.1-0.037-0.15-0.044 0 0-0.006 0-0.006 0-0.013 0-0.019 0-0.031 0-0.006 0-0.019 0-0.025 0s-0.006 0-0.013 0c-0.013 0-0.025 0-0.037 0.006 0 0 0 0 0 0-0.037 0.006-0.075 0.019-0.112 0.037 0 0 0 0 0 0-0.006 0-0.006 0.006-0.013 0.006-0.006 0.006-0.013 0.006-0.019 0.012 0 0-0.006 0-0.006 0-0.013 0.006-0.019 0.012-0.031 0.019 0 0 0 0-0.006 0.006-0.013 0.006-0.019 0.012-0.025 0.025 0 0 0 0-0.006 0-0.006 0.006-0.019 0.019-0.025 0.025 0 0 0 0 0 0-0.006 0.012-0.019 0.019-0.025 0.031 0 0 0 0 0 0-0.013 0.019-0.019 0.031-0.031 0.050l-6.894 12.494c-0.031 0.056-0.050 0.119-0.056 0.181 0 0.006 0 0.019 0 0.025 0 0 0 0 0 0 0 4.038 3.281 7.319 7.319 7.319 4.031 0 7.312-3.281 7.312-7.319 0 0 0 0 0 0 0-0.019 0-0.044-0.006-0.069zM7.569 11.506l6.188 11.231h-12.381l6.194-11.231zM7.569 29.631c-3.431 0-6.25-2.681-6.469-6.063h12.931c-0.213 3.381-3.031 6.063-6.463 6.063z"></path>
<path fill="#5e686c" d="M31.544 22.95l-6.938-12.512c0-0.006-0.006-0.006-0.006-0.012-0.006-0.006-0.006-0.012-0.012-0.019s-0.006-0.006-0.012-0.012-0.012-0.012-0.019-0.019c0-0.006-0.006-0.006-0.006-0.012-0.006-0.006-0.012-0.012-0.019-0.019 0-0.006-0.006-0.006-0.012-0.006-0.006-0.006-0.012-0.012-0.019-0.019-0.006 0-0.006-0.006-0.012-0.006-0.006-0.006-0.012-0.012-0.025-0.019-0.006 0-0.006-0.006-0.012-0.006-0.006-0.006-0.012-0.006-0.019-0.012 0 0-0.006 0-0.006-0.006-0.006 0-0.006-0.006-0.012-0.006-0.006-0.006-0.019-0.006-0.025-0.012-0.006 0-0.006 0-0.012-0.006s-0.019-0.006-0.025-0.006c-0.006 0-0.006 0-0.012-0.006-0.006 0-0.019-0.006-0.025-0.006s-0.019 0-0.025-0.006c-0.006 0-0.006 0-0.012 0-0.075-0.006-0.156 0.006-0.225 0.044 0 0-0.006 0-0.006 0.006 0 0-0.006 0-0.006 0.006-0.006 0-0.012 0.006-0.012 0.006-0.006 0-0.006 0.006-0.012 0.006-0.006 0.006-0.012 0.006-0.019 0.012s-0.006 0.006-0.012 0.012-0.012 0.012-0.019 0.019c-0.006 0.006-0.006 0.006-0.012 0.012s-0.012 0.012-0.019 0.019c0 0.006-0.006 0.006-0.006 0.012-0.006 0.006-0.012 0.012-0.019 0.025 0 0.006-0.006 0.006-0.006 0.012-0.006 0.006-0.012 0.019-0.019 0.025 0 0 0 0.006-0.006 0.006l-6.794 12.381c-0.1 0.075-0.163 0.194-0.163 0.331 0 4.031 3.281 7.319 7.319 7.319 3.975 0 7.219-3.181 7.313-7.137 0.056-0.119 0.063-0.262-0.006-0.387zM24.244 11.506l6.225 11.225h-12.381l6.156-11.225zM24.238 29.631c-3.431 0-6.25-2.681-6.469-6.063h12.931c-0.212 3.381-3.031 6.063-6.462 6.063z"></path>
</svg>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.legal">Legal</a>
                              <div class="badge inside bg-grey ml-1">NEW</div>
                              <p>Eaque ipsa quae ab illo inventore veritatis et quasi</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg" src="fonts/svg/blog.svg" alt="Knowledgebase">
<title>blog</title>
<path fill="#5e686c" d="M21.175 31.563h-10.119c-0.019 0-0.037 0-0.056-0.006-5.888-0.063-10.488-4.669-10.488-10.506v-10.069c0-5.769 4.725-10.494 10.544-10.531h4.425c0.025-0.006 0.056-0.006 0.075-0.006 5.644 0.037 10.081 4.344 10.375 10.031 0.012 0.044 0.025 0.088 0.025 0.137 0 0.031 0 0.056-0.006 0.088 0.137 0.381 0.569 1.137 1.738 1.137h1.387c1.363 0 2.563 1.125 2.563 2.412v6.806c0 6.031-5.45 10.356-10.369 10.5-0.038 0-0.069 0.006-0.094 0.006zM11.106 30.712h9.988c0.019-0.006 0.044-0.006 0.069-0.006 4.55-0.094 9.619-4.081 9.619-9.656v-6.8c0-0.806-0.831-1.569-1.719-1.569h-1.387c-1.769 0-2.494-1.319-2.625-2.019-0.019-0.081-0.006-0.169 0.025-0.244-0.313-5.162-4.338-9.063-9.456-9.131-0.025 0.006-0.044 0.006-0.069 0.006h-4.494c-5.438 0.038-9.7 4.294-9.7 9.688v10.069c0 5.387 4.263 9.625 9.706 9.663 0.012 0 0.025 0 0.044 0z"></path>
<path id="svg-ico" fill="#ee5586" d="M22.688 22.038h-14.287c-0.231 0-0.425-0.188-0.425-0.425 0-0.231 0.188-0.425 0.425-0.425h14.287c0.231 0 0.425 0.188 0.425 0.425-0.006 0.231-0.194 0.425-0.425 0.425z"></path>
<path id="svg-ico" fill="#ee5586" d="M17.95 12.681h-9.55c-0.231 0-0.425-0.188-0.425-0.425s0.187-0.425 0.425-0.425h9.55c0.231 0 0.425 0.188 0.425 0.425s-0.188 0.425-0.425 0.425z"></path>
</svg>
                            </div>
                            <div class="media-body">
                              <div>
                                <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.blog">Blog</a>
                                <div class="badge inside bg-pink ml-1">HOT</div>
                              </div>
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                            </div>
                          </div>
                          <div class="col-4 service">
                            <div class="media-left">
                              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg" src="fonts/svg/question.svg" alt="Knowledgebase">
<title>question</title>
<path id="svg-ico" fill="#ee5586" d="M16.113 25.962c-1.2 0-2.175-0.975-2.175-2.175s0.975-2.175 2.175-2.175 2.175 0.975 2.175 2.175-0.975 2.175-2.175 2.175zM16.113 22.488c-0.719 0-1.306 0.587-1.306 1.306s0.588 1.306 1.306 1.306c0.719 0 1.306-0.587 1.306-1.306-0.006-0.725-0.587-1.306-1.306-1.306z"></path>
<path fill="#5e686b" d="M16.106 31.594c-8.631 0-15.656-7.025-15.656-15.656s7.025-15.656 15.656-15.656c7.969 0 14.656 5.963 15.556 13.869 0.025 0.238-0.144 0.456-0.381 0.481-0.238 0.019-0.456-0.144-0.481-0.381-0.85-7.463-7.162-13.094-14.688-13.094-8.162-0.006-14.794 6.631-14.794 14.781s6.631 14.788 14.788 14.788c7.525 0 13.837-5.631 14.688-13.094 0.025-0.238 0.244-0.406 0.481-0.381s0.413 0.244 0.381 0.481c-0.894 7.9-7.581 13.863-15.55 13.863z"></path>
<path id="svg-ico" fill="#ee5586" d="M16.206 18.1c-0.238 0-0.438-0.194-0.438-0.438v-1.175c0-0.675 0.213-1.281 0.625-1.794 0.363-0.456 0.762-0.906 1.194-1.35 0.413-0.425 0.788-0.881 1.119-1.35 0.3-0.425 0.45-0.925 0.45-1.525 0-0.444-0.069-0.9-0.206-1.344-0.131-0.425-0.344-0.806-0.619-1.125s-0.65-0.581-1.119-0.787c-0.469-0.206-1.050-0.313-1.719-0.313-0.544 0-1.050 0.106-1.512 0.313s-0.869 0.494-1.2 0.863c-0.338 0.375-0.613 0.838-0.819 1.363-0.206 0.537-0.319 1.137-0.331 1.781-0.006 0.238-0.2 0.425-0.438 0.425 0 0-0.006 0-0.012 0-0.238-0.006-0.431-0.206-0.425-0.444 0.019-0.75 0.15-1.45 0.387-2.075 0.244-0.631 0.569-1.181 0.981-1.631 0.412-0.456 0.912-0.819 1.488-1.075 0.569-0.256 1.2-0.388 1.869-0.388 0.794 0 1.488 0.131 2.069 0.388s1.063 0.594 1.425 1.013c0.356 0.412 0.625 0.894 0.794 1.438 0.163 0.531 0.25 1.069 0.25 1.6 0 0.775-0.206 1.456-0.606 2.025-0.356 0.506-0.762 0.994-1.2 1.456-0.413 0.425-0.794 0.856-1.137 1.287-0.288 0.363-0.431 0.775-0.431 1.25v1.175c0 0.244-0.2 0.438-0.438 0.438z"></path>
</svg>
                            </div>
                            <div class="media-body">
                              <a class="menu-item" href="http://arvrt.in/" data-i18n="[html]submenu.faq">FAQ</a>
                              <p>Eaque ipsa quae ab illo inventore veritatis et quasi</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="start-offer col-md-3">
                        <div class="inner">
                          <div class="title mb-2">Adbhut</div>
                          <div class="inner-content"><span>Call us:</span> <b>+91 6395 996 304</b> HeadQuarters - </div>
                          <a href="http://arvrt.in/contact-us.php" class="btn btn-default-yellow-fill mt-4">Contact</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
			  <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){
              $user_id=$_SESSION['id']; 
             $sql_user="select * from user_profile where id='$user_id'";
              $result_user = mysqli_query($conn, $sql_user);
              $res_user= mysqli_fetch_array($result_user); ?>
			         <li class="menu-item">
                <a class="pr-0 mr-0" href=""> <div class="btn btn-default-yellow-fill question" data-i18n="[html]header.login"><?= $res_user['fname'];?></div></a>
              </li>
              <li class="menu-item">
                <a class="pr-0 mr-0" href="logout.php"> <div class="btn btn-default-yellow-fill question" data-i18n="[html]header.login">Logout</div></a>
              </li><?php } else{ ?>
            <li class="menu-item">
                <a class="pr-0 mr-0" href="login.php"> <div class="btn btn-default-yellow-fill question" data-i18n="[html]header.login">Log In</div></a>
              </li>
              <li class="menu-item">
                <a class="pr-0 mr-0" href="signup.php"> <div class="btn btn-default-yellow-fill question" data-i18n="[html]header.login">Sign Up</div></a>
              </li><?php } ?>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>
<!-- ***** NAV MENU MOBILE ****** -->
<div class="menu-wrap mobile">
  <div class="container">
    <div class="row">
      <div class="col-6">
        <a href="http://arvrt.in/"><img src="img/adbhut-bharat.png" class="img-fluid"></a>
      </div>
      <div class="col-6">
        <nav class="nav-menu">
          <button id="nav-toggle" class="menu-toggle">
            <span class="icon"></span>
            <span class="icon"></span>
            <span class="icon"></span>
          </button>
          <div class="main-menu">
            <div class="menu-item">
              <a href="http://arvrt.in/" data-toggle="dropdown">Home <div class="badge badge-pill bg-purple">NEW</div></a>
              <div class="dropdown-menu">
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/index">Home Default</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/homevideo">Home Video</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/homeimage">Home Image</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/homegaming">Home Gaming <div class="badge inside bg-purple ml-2">NEW</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/home3d">Home 3D <div class="badge inside bg-purple ml-2">NEW</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template-rtl/" target="_blank">Antler (RTL) 
                  <div class="badge inside bg-pink ml-2">NEW</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/whmcs/?systpl=antler-rtl&amp;language=arabic" target="_blank">WHMCS (RTL) 
                  <div class="badge inside bg-pink ml-2">NEW</div></a>
              </div>
            </div>
            <div class="menu-item">
              <a href="#" data-toggle="dropdown">Hosting <div class="badge badge-pill bg-purple">PRO</div></a>
              <div class="dropdown-menu">
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/hosting">Online Pesence</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/reseller">Cloud Reseller</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/dedicated">Dedicated Server</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/vps">Cloud VPS</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/wordPress">WordPress Hosting</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/domains">Domain Names</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/developer">Developer Hosting</a>
              </div>
            </div>
            <div class="menu-item">
              <a href="#" data-toggle="dropdown">Pages</a>
              <div class="dropdown-menu">
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/emailsecurity">Email Security</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/ssl">SSL Certificates</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/mail">Enterprise Email</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/magento">Magento Pro</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/gsuite"> Suite - Google</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/iptv">IPTV System</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/ddos">DDoS Protection</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/datacenter">Datacenter <div class="badge inside bg-grey ml-2">TOP</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/about">bout Us</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/database">Database-as-a-Service</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/elements">Elements</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/voip">Virtual Numbers</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/voice">Voice Server <div class="badge inside bg-pink ml-2">NEW</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/payments">Payment Methods <div class="badge inside bg-pink ml-2">NEW</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/configurator">Configurator <div class="badge inside bg-grey ml-2">HOT</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/cart">Cart</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/checkout">Checkout</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/soon">Coming Soon</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/promos">Promotions</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/blackfriday">Blackfriday <div class="badge inside bg-pink ml-2">HOT</div></a>
              </div>
            </div>
            <div class="menu-item">
              <a href="#" data-toggle="dropdown">Features</a>
              <div class="dropdown-menu">
                <a class="dropdown-item menu-item" href="http://inebur.com/whmcs/?systpl=antler" target="_blank">WHMCS Template <div class="badge inside bg-pink">HOT</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/whmcs/cart.php?gid=2?systpl=antler" target="_blank">Order Form Template <div class="badge inside bg-grey">TOP</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/email/" target="_blank">HMCS Email Template <div class="badge inside bg-grey">TOP</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/newsletter/" target="_blank">WHMCS Newsletter Template <div class="badge inside bg-grey">TOP</div></a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/pricing">Pricing Options</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/sliders">Content Sliders</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/configurator">Configurator</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/404">404 Error</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/login">Register</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/login">Client Area</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/elements">Elements</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/sections">Sections</a>
              </div>
            </div>
            <div class="menu-item menu-last">
              <a href="#" data-toggle="dropdown">Support</a>
              <div class="dropdown-menu">
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/knowledgebase-list">Knowlege List</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/knowledgebase-article">Knowlege Article</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/contact">Contact Us</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/legal">Legal</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/blog">Blog</a>
                <a class="dropdown-item menu-item" href="http://inebur.com/antler/template/faq">Faq</a>
              </div>
            </div>
            <div class="float-left w-100 mt-3">
              <p class="c-grey"> <small> Phone: + (123) 1300-656-1046</small> </p>
              <p class="c-grey"><small>Email: antler@mail.com</small> </p>
            </div>
            <div>
              <a href="http://inebur.com/antler/template/login"><div class="btn btn-default-yellow-fill mt-3">CLIENT AREA</div></a>
            </div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>
<!-- ***** COLORS ****** -->
<section>
    <ul class="color-scheme">            
      <li class="pink"><a href="#" data-rel="pink" class="styleswitch"></a></li>
      <li class="blue"><a href="#" data-rel="blue" class="styleswitch"></a></li>
      <li class="green"><a href="#" data-rel="green" class="styleswitch"></a></li>
    </ul> 
</section>
<!-- ***** TRANSLATION ****** -->
<section id="drop-lng" class="btn-group btn-group-toggle toplang" data-toggle="buttons">
  <label data-lng="en-US" class="btn btn-secondary mb-2">
    <input type="radio" name="options" id="option1"> EN
  </label>
  <label data-lng="pt-PT" class="btn btn-secondary xpto active">
    <input type="radio" name="options" id="option2"> PT
  </label>
</section>
<!-- Javascript -->
<script defer="defer" src="aft_files/scripts_002.js"></script>
<script>
$("#nav-toggle").click(function(){
$(".menu-wrap.mobile, .menu-toggle").toggleClass("active");
});
</script></header>