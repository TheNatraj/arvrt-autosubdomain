<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<div class="container pricing">
  <div class="row">
    <div id="carouselPlus" class="carousel slide multi-carousel" data-ride="carousel">
      <div class="carousel-inner">       
        <div class="carousel-grid col-lg-4 col-md-4 col-sm-12">	
		<div class="wrapper first text-left">
            <div class="top-content">
              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg mb-3" src="fonts/svg/cloudfiber.svg" alt="">
<title>cloudfiber</title>
<path id="svg-ico" fill="#ee5586" d="M21.294 1.969c-0.012 0-0.025 0-0.038 0h-0.156c-0.012 0-0.025 0-0.038 0-5.325 0.087-10.656 3.756-10.656 10.688 0 0.238 0.194 0.425 0.425 0.425 0.238 0 0.425-0.194 0.425-0.425 0-6.719 5.125-9.8 9.912-9.838 5.387 0.038 9.762 4.438 9.762 9.838 0 5.425-4.412 9.837-9.838 9.837h-13.325c-3.725 0-6.756-3.031-6.756-6.756s3.031-6.756 6.756-6.756c0.238 0 0.425-0.194 0.425-0.425s-0.194-0.425-0.425-0.425c-4.2-0.006-7.612 3.412-7.612 7.606s3.413 7.613 7.612 7.613h13.331c5.894 0 10.694-4.794 10.694-10.694 0-5.825-4.694-10.581-10.5-10.688z"></path>
<path fill="#5e686c" d="M24.413 28.15h-6.781c-0.156-0.6-0.631-1.075-1.231-1.231v-2.194c0-0.238-0.194-0.425-0.425-0.425-0.238 0-0.425 0.194-0.425 0.425v2.194c-0.6 0.156-1.075 0.631-1.231 1.231h-6.781c-0.237 0-0.425 0.194-0.425 0.425s0.194 0.425 0.425 0.425h6.781c0.188 0.738 0.863 1.281 1.656 1.281s1.469-0.544 1.656-1.281h6.781c0.238 0 0.425-0.194 0.425-0.425s-0.188-0.425-0.425-0.425zM15.975 29.431c-0.469 0-0.856-0.381-0.856-0.856 0 0 0 0 0 0s0 0 0 0c0-0.469 0.381-0.856 0.856-0.856s0.856 0.381 0.856 0.856c0 0.475-0.387 0.856-0.856 0.856z"></path>
<path fill="#5e686c" d="M21.238 6.931c0.238 0 0.425-0.194 0.425-0.431-0.006-0.237-0.219-0.444-0.431-0.425-3.381 0.044-6.375 2.719-6.675 6.044l0.006 0.075c0.006 0.156 0.012 0.313 0.012 0.463 0 0.238 0.194 0.425 0.425 0.425 0.238 0 0.425-0.194 0.425-0.425 0-0.162-0.006-0.331-0.012-0.525l-0.012-0.019c0.269-2.819 2.888-5.144 5.838-5.181z"></path>
</svg>
              <div class="title">Shared Hosting</div>
              <div class="fromer">Starting at:</div>
              <div class="price"><sup>$</sup>8.19 <span class="period">/month</span></div>
              <a href="hosting" class="btn btn-default-yellow-fill">All plans</a>
            </div>
            <ul class="list-info">
              <li><i class="icon-drives"></i> <span class="c-purple">DISK</span><br> <span>250GB SSD</span></li>
              <li><i class="icon-speed"></i> <span class="c-purple">DATA</span><br> <span>1TB Bandwidth</span></li>
              <li><i class="icon-emailopen"></i> <span class="c-purple">EMAIL</span><br> <span>120 Emails</span></li>
              <li><i class="icon-domains"></i> <span class="c-purple">TLD</span><br> <span>30 Domains</span></li>
            </ul>
          </div> 
		</div>
		
        <div class="carousel-grid col-lg-4 col-md-4 col-sm-12">	
		<div class="wrapper text-left">
            <div class="plans badge feat bg-pink">recommended</div>
            <div class="top-content">
              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg mb-3" src="fonts/svg/dedicated.svg" alt="">
<title>dedicated</title>
<path id="svg-ico" fill="#ee5586" d="M24.681 17.744c-0.925 0-1.681 0.756-1.681 1.681 0 0.931 0.756 1.681 1.681 1.681s1.681-0.756 1.681-1.681c0-0.925-0.756-1.681-1.681-1.681zM24.681 20.269c-0.462 0-0.844-0.375-0.844-0.844 0-0.462 0.375-0.837 0.844-0.837s0.844 0.375 0.844 0.837c0 0.469-0.381 0.844-0.844 0.844z"></path>
<path fill="#5e686c" d="M29.544 13.537h-27.087c-1.113 0-2.019 0.838-2.019 1.863v8.050c0 1.025 0.906 1.863 2.025 1.863h27.081c1.113 0 2.019-0.837 2.019-1.863v-8.050c0-1.025-0.906-1.863-2.019-1.863zM30.719 23.45c0 0.563-0.531 1.025-1.181 1.025h-27.081c-0.65 0-1.181-0.456-1.181-1.025v-8.050c0-0.563 0.531-1.025 1.181-1.025h27.081c0.65 0 1.181 0.456 1.181 1.025v8.050z"></path>
<path id="svg-ico" fill="#ee5586" d="M24.681 4.662c-0.925 0-1.681 0.756-1.681 1.681 0 0.931 0.756 1.681 1.681 1.681s1.681-0.756 1.681-1.681c0-0.931-0.756-1.681-1.681-1.681zM24.681 7.188c-0.462 0-0.844-0.381-0.844-0.844s0.375-0.838 0.844-0.838 0.844 0.375 0.844 0.838c0 0.463-0.381 0.844-0.844 0.844z"></path>
<path fill="#5e686c" d="M29.544 0.456h-27.087c-1.113 0-2.019 0.831-2.019 1.863v8.050c0 1.025 0.906 1.863 2.025 1.863h27.081c1.113 0 2.019-0.838 2.019-1.863v-8.050c0-1.031-0.906-1.863-2.019-1.863zM30.719 10.369c0 0.563-0.531 1.025-1.181 1.025h-27.081c-0.65 0-1.181-0.456-1.181-1.025v-8.050c0-0.563 0.531-1.025 1.181-1.025h27.081c0.65 0 1.181 0.456 1.181 1.025v8.050z"></path>
<path fill="#5e686c" d="M25.988 29.8h-8.356c-0.15-0.594-0.619-1.056-1.206-1.212v-1.875c0-0.231-0.188-0.419-0.419-0.419s-0.419 0.188-0.419 0.419v1.875c-0.588 0.15-1.056 0.619-1.206 1.212h-8.369c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h8.356c0.188 0.725 0.85 1.262 1.631 1.262s1.444-0.538 1.631-1.262h8.356c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419zM16 31.063c-0.463 0-0.844-0.375-0.844-0.844 0-0.462 0.375-0.844 0.844-0.844 0.462 0 0.844 0.375 0.844 0.844-0.006 0.462-0.381 0.844-0.844 0.844z"></path>
</svg>
              <div class="title">Dedicated Server</div>
              <div class="fromer">annually get (20% discount)</div>
              <div class="price"><sup>$</sup>82.00 <span class="period">/month</span></div>
              <a href="configurator" class="btn btn-default-yellow-fill">Configure</a>
            </div>
            <ul class="list-info bg-purple">
              <li><i class="icon-cpu"></i> <span class="c-pink">CPU</span><br> <span>4x 3.20Ghz 2 Cores</span></li>
              <li><i class="icon-ram"></i> <span class="c-pink">RAM</span><br> <span>16GB (up to 32GB)</span></li>
              <li><i class="icon-drivessd"></i> <span class="c-pink">DRIVES</span><br> <span>2 x 1TB SATA 3.5</span></li>
              <li><i class="icon-git"></i> <span class="c-pink">UPLINK</span><br> <span>1Gbps - 20TB</span></li>
            </ul>
          </div> 
		</div>
		
        <div class="carousel-grid col-lg-4 col-md-4 col-sm-12">	
		<div class="wrapper third text-left">
            <div class="top-content">
              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg mb-3" src="fonts/svg/vps.svg" alt="">
<title>vps</title>
<path fill="#5e686b" d="M29.55 13.35h-16.175c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h16.175c0.65 0 1.181 0.456 1.181 1.025v8.050c0 0.563-0.531 1.025-1.181 1.025h-27.081c-0.65 0-1.181-0.456-1.181-1.025v-8.050c0-0.563 0.531-1.025 1.181-1.025h4.175c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-4.175c-1.113 0-2.025 0.838-2.025 1.863v8.050c0 1.025 0.906 1.863 2.025 1.863h27.081c1.113 0 2.019-0.837 2.019-1.863v-8.050c0.006-1.025-0.906-1.863-2.019-1.863z"></path>
<path fill="#5e686b" d="M29.55 0.269h-16.175c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h16.175c0.65 0 1.181 0.456 1.181 1.025v8.050c0 0.563-0.531 1.025-1.181 1.025h-27.081c-0.65 0-1.181-0.456-1.181-1.025v-8.050c0-0.563 0.531-1.025 1.181-1.025h4.175c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-4.175c-1.113 0-2.019 0.831-2.019 1.862v8.050c0 1.025 0.906 1.863 2.025 1.863h27.081c1.113 0 2.019-0.838 2.019-1.863v-8.050c0-1.025-0.913-1.863-2.025-1.863z"></path>
<path id="svg-ico" fill="#ee5586" d="M25.775 19.663c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-2.169c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h2.169z"></path>
<path id="svg-ico" fill="#ee5586" d="M25.775 6.575c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-2.169c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h2.169z"></path>
<path fill="#5e686b" d="M25.994 29.613h-8.356c-0.15-0.594-0.619-1.056-1.206-1.212v-1.875c0-0.231-0.188-0.419-0.419-0.419s-0.419 0.188-0.419 0.419v1.875c-0.588 0.15-1.056 0.619-1.206 1.212h-8.363c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h8.356c0.188 0.725 0.85 1.262 1.631 1.262s1.444-0.538 1.631-1.262h8.356c0.231 0 0.419-0.188 0.419-0.419-0.006-0.231-0.194-0.419-0.425-0.419zM16.012 30.875c-0.463 0-0.844-0.375-0.844-0.844 0-0.462 0.375-0.844 0.844-0.844 0.462 0 0.844 0.375 0.844 0.844-0.006 0.462-0.381 0.844-0.844 0.844z"></path>
</svg>
              <div class="title">Cloud VPS</div>
              <div class="fromer">Starting at:</div>
              <div class="price"><sup>$</sup>9.99 <span class="period">/month</span></div>
              <a href="vps" class="btn btn-default-yellow-fill">All plans</a>
            </div>
            <ul class="list-info">
              <li><i class="icon-cpu"></i> <span class="c-purple">CPU</span><br> <span>2 Cores</span></li>
              <li><i class="icon-ram"></i> <span class="c-purple">RAM</span><br> <span>2GB Memory</span></li>
              <li><i class="icon-drives"></i> <span class="c-purple">DISK</span><br> <span>20GB SSD Space</span></li>
              <li><i class="icon-speed"></i> <span class="c-purple">DATA</span><br> <span>1TB Bandwidth</span></li>
            </ul>
          </div>
		</div>
 <div class="carousel-grid col-lg-4 col-md-4 col-sm-12">	
		<div class="wrapper first text-left">
            <div class="top-content">
              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg mb-3" src="fonts/svg/cloudfiber.svg" alt="">
<title>cloudfiber</title>
<path id="svg-ico" fill="#ee5586" d="M21.294 1.969c-0.012 0-0.025 0-0.038 0h-0.156c-0.012 0-0.025 0-0.038 0-5.325 0.087-10.656 3.756-10.656 10.688 0 0.238 0.194 0.425 0.425 0.425 0.238 0 0.425-0.194 0.425-0.425 0-6.719 5.125-9.8 9.912-9.838 5.387 0.038 9.762 4.438 9.762 9.838 0 5.425-4.412 9.837-9.838 9.837h-13.325c-3.725 0-6.756-3.031-6.756-6.756s3.031-6.756 6.756-6.756c0.238 0 0.425-0.194 0.425-0.425s-0.194-0.425-0.425-0.425c-4.2-0.006-7.612 3.412-7.612 7.606s3.413 7.613 7.612 7.613h13.331c5.894 0 10.694-4.794 10.694-10.694 0-5.825-4.694-10.581-10.5-10.688z"></path>
<path fill="#5e686c" d="M24.413 28.15h-6.781c-0.156-0.6-0.631-1.075-1.231-1.231v-2.194c0-0.238-0.194-0.425-0.425-0.425-0.238 0-0.425 0.194-0.425 0.425v2.194c-0.6 0.156-1.075 0.631-1.231 1.231h-6.781c-0.237 0-0.425 0.194-0.425 0.425s0.194 0.425 0.425 0.425h6.781c0.188 0.738 0.863 1.281 1.656 1.281s1.469-0.544 1.656-1.281h6.781c0.238 0 0.425-0.194 0.425-0.425s-0.188-0.425-0.425-0.425zM15.975 29.431c-0.469 0-0.856-0.381-0.856-0.856 0 0 0 0 0 0s0 0 0 0c0-0.469 0.381-0.856 0.856-0.856s0.856 0.381 0.856 0.856c0 0.475-0.387 0.856-0.856 0.856z"></path>
<path fill="#5e686c" d="M21.238 6.931c0.238 0 0.425-0.194 0.425-0.431-0.006-0.237-0.219-0.444-0.431-0.425-3.381 0.044-6.375 2.719-6.675 6.044l0.006 0.075c0.006 0.156 0.012 0.313 0.012 0.463 0 0.238 0.194 0.425 0.425 0.425 0.238 0 0.425-0.194 0.425-0.425 0-0.162-0.006-0.331-0.012-0.525l-0.012-0.019c0.269-2.819 2.888-5.144 5.838-5.181z"></path>
</svg>
              <div class="title">Shared Hosting</div>
              <div class="fromer">Starting at:</div>
              <div class="price"><sup>$</sup>8.19 <span class="period">/month</span></div>
              <a href="hosting" class="btn btn-default-yellow-fill">All plans</a>
            </div>
            <ul class="list-info">
              <li><i class="icon-drives"></i> <span class="c-purple">DISK</span><br> <span>250GB SSD</span></li>
              <li><i class="icon-speed"></i> <span class="c-purple">DATA</span><br> <span>1TB Bandwidth</span></li>
              <li><i class="icon-emailopen"></i> <span class="c-purple">EMAIL</span><br> <span>120 Emails</span></li>
              <li><i class="icon-domains"></i> <span class="c-purple">TLD</span><br> <span>30 Domains</span></li>
            </ul>
          </div> 
		</div>
		
        <div class="carousel-grid col-lg-4 col-md-4 col-sm-12">	
		<div class="wrapper text-left">
            <div class="plans badge feat bg-pink">recommended</div>
            <div class="top-content">
              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg mb-3" src="fonts/svg/dedicated.svg" alt="">
<title>dedicated</title>
<path id="svg-ico" fill="#ee5586" d="M24.681 17.744c-0.925 0-1.681 0.756-1.681 1.681 0 0.931 0.756 1.681 1.681 1.681s1.681-0.756 1.681-1.681c0-0.925-0.756-1.681-1.681-1.681zM24.681 20.269c-0.462 0-0.844-0.375-0.844-0.844 0-0.462 0.375-0.837 0.844-0.837s0.844 0.375 0.844 0.837c0 0.469-0.381 0.844-0.844 0.844z"></path>
<path fill="#5e686c" d="M29.544 13.537h-27.087c-1.113 0-2.019 0.838-2.019 1.863v8.050c0 1.025 0.906 1.863 2.025 1.863h27.081c1.113 0 2.019-0.837 2.019-1.863v-8.050c0-1.025-0.906-1.863-2.019-1.863zM30.719 23.45c0 0.563-0.531 1.025-1.181 1.025h-27.081c-0.65 0-1.181-0.456-1.181-1.025v-8.050c0-0.563 0.531-1.025 1.181-1.025h27.081c0.65 0 1.181 0.456 1.181 1.025v8.050z"></path>
<path id="svg-ico" fill="#ee5586" d="M24.681 4.662c-0.925 0-1.681 0.756-1.681 1.681 0 0.931 0.756 1.681 1.681 1.681s1.681-0.756 1.681-1.681c0-0.931-0.756-1.681-1.681-1.681zM24.681 7.188c-0.462 0-0.844-0.381-0.844-0.844s0.375-0.838 0.844-0.838 0.844 0.375 0.844 0.838c0 0.463-0.381 0.844-0.844 0.844z"></path>
<path fill="#5e686c" d="M29.544 0.456h-27.087c-1.113 0-2.019 0.831-2.019 1.863v8.050c0 1.025 0.906 1.863 2.025 1.863h27.081c1.113 0 2.019-0.838 2.019-1.863v-8.050c0-1.031-0.906-1.863-2.019-1.863zM30.719 10.369c0 0.563-0.531 1.025-1.181 1.025h-27.081c-0.65 0-1.181-0.456-1.181-1.025v-8.050c0-0.563 0.531-1.025 1.181-1.025h27.081c0.65 0 1.181 0.456 1.181 1.025v8.050z"></path>
<path fill="#5e686c" d="M25.988 29.8h-8.356c-0.15-0.594-0.619-1.056-1.206-1.212v-1.875c0-0.231-0.188-0.419-0.419-0.419s-0.419 0.188-0.419 0.419v1.875c-0.588 0.15-1.056 0.619-1.206 1.212h-8.369c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h8.356c0.188 0.725 0.85 1.262 1.631 1.262s1.444-0.538 1.631-1.262h8.356c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419zM16 31.063c-0.463 0-0.844-0.375-0.844-0.844 0-0.462 0.375-0.844 0.844-0.844 0.462 0 0.844 0.375 0.844 0.844-0.006 0.462-0.381 0.844-0.844 0.844z"></path>
</svg>
              <div class="title">Dedicated Server</div>
              <div class="fromer">annually get (20% discount)</div>
              <div class="price"><sup>$</sup>82.00 <span class="period">/month</span></div>
              <a href="configurator" class="btn btn-default-yellow-fill">Configure</a>
            </div>
            <ul class="list-info bg-purple">
              <li><i class="icon-cpu"></i> <span class="c-pink">CPU</span><br> <span>4x 3.20Ghz 2 Cores</span></li>
              <li><i class="icon-ram"></i> <span class="c-pink">RAM</span><br> <span>16GB (up to 32GB)</span></li>
              <li><i class="icon-drivessd"></i> <span class="c-pink">DRIVES</span><br> <span>2 x 1TB SATA 3.5</span></li>
              <li><i class="icon-git"></i> <span class="c-pink">UPLINK</span><br> <span>1Gbps - 20TB</span></li>
            </ul>
          </div> 
		</div>
		
        <div class="carousel-grid col-lg-4 col-md-4 col-sm-12">	
		<div class="wrapper third text-left">
            <div class="top-content">
              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" class="svg mb-3" src="fonts/svg/vps.svg" alt="">
<title>vps</title>
<path fill="#5e686b" d="M29.55 13.35h-16.175c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h16.175c0.65 0 1.181 0.456 1.181 1.025v8.050c0 0.563-0.531 1.025-1.181 1.025h-27.081c-0.65 0-1.181-0.456-1.181-1.025v-8.050c0-0.563 0.531-1.025 1.181-1.025h4.175c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-4.175c-1.113 0-2.025 0.838-2.025 1.863v8.050c0 1.025 0.906 1.863 2.025 1.863h27.081c1.113 0 2.019-0.837 2.019-1.863v-8.050c0.006-1.025-0.906-1.863-2.019-1.863z"></path>
<path fill="#5e686b" d="M29.55 0.269h-16.175c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h16.175c0.65 0 1.181 0.456 1.181 1.025v8.050c0 0.563-0.531 1.025-1.181 1.025h-27.081c-0.65 0-1.181-0.456-1.181-1.025v-8.050c0-0.563 0.531-1.025 1.181-1.025h4.175c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-4.175c-1.113 0-2.019 0.831-2.019 1.862v8.050c0 1.025 0.906 1.863 2.025 1.863h27.081c1.113 0 2.019-0.838 2.019-1.863v-8.050c0-1.025-0.913-1.863-2.025-1.863z"></path>
<path id="svg-ico" fill="#ee5586" d="M25.775 19.663c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-2.169c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h2.169z"></path>
<path id="svg-ico" fill="#ee5586" d="M25.775 6.575c0.231 0 0.419-0.188 0.419-0.419s-0.188-0.419-0.419-0.419h-2.169c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h2.169z"></path>
<path fill="#5e686b" d="M25.994 29.613h-8.356c-0.15-0.594-0.619-1.056-1.206-1.212v-1.875c0-0.231-0.188-0.419-0.419-0.419s-0.419 0.188-0.419 0.419v1.875c-0.588 0.15-1.056 0.619-1.206 1.212h-8.363c-0.231 0-0.419 0.188-0.419 0.419s0.188 0.419 0.419 0.419h8.356c0.188 0.725 0.85 1.262 1.631 1.262s1.444-0.538 1.631-1.262h8.356c0.231 0 0.419-0.188 0.419-0.419-0.006-0.231-0.194-0.419-0.425-0.419zM16.012 30.875c-0.463 0-0.844-0.375-0.844-0.844 0-0.462 0.375-0.844 0.844-0.844 0.462 0 0.844 0.375 0.844 0.844-0.006 0.462-0.381 0.844-0.844 0.844z"></path>
</svg>
              <div class="title">Cloud VPS</div>
              <div class="fromer">Starting at:</div>
              <div class="price"><sup>$</sup>9.99 <span class="period">/month</span></div>
              <a href="vps" class="btn btn-default-yellow-fill">All plans</a>
            </div>
            <ul class="list-info">
              <li><i class="icon-cpu"></i> <span class="c-purple">CPU</span><br> <span>2 Cores</span></li>
              <li><i class="icon-ram"></i> <span class="c-purple">RAM</span><br> <span>2GB Memory</span></li>
              <li><i class="icon-drives"></i> <span class="c-purple">DISK</span><br> <span>20GB SSD Space</span></li>
              <li><i class="icon-speed"></i> <span class="c-purple">DATA</span><br> <span>1TB Bandwidth</span></li>
            </ul>
          </div>
		</div>		
      </div>
      <a class="carousel-control-prev" href="#carouselPlus" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselPlus" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>      
    </div>
  </div>
</div>
  
<div id="lg" class="d-none d-lg-block"></div><div id="md" class="d-none d-md-block d-lg-none"></div><div id="sm" class="d-none d-sm-block d-md-none"></div>

<script>
var $origin = $("#carouselPlus .carousel-inner").prop("outerHTML");
function multiCarousel(){
	if ( $( "#lg" ).is( ":visible" ) ) {
		do {
			$( "#carouselPlus .carousel-inner" ).children( ".carousel-grid:lt(3)" ).wrapAll( "<div class=\"carousel-item\"><div class=\"row\"></div></div>" );
			$( "#carouselPlus .carousel-inner .carousel-item:first" ).addClass("active");
		} while ( $( "#carouselPlus .carousel-inner" ).children( ".carousel-grid" ).length );
	} else if ( $( "#md" ).is( ":visible" ) ) {
		do {
			$( "#carouselPlus .carousel-inner" ).children( ".carousel-grid:lt(1)" ).wrapAll( "<div class=\"carousel-item\"><div class=\"row\"></div></div>" );
			$( "#carouselPlus .carousel-inner .carousel-item:first" ).addClass("active");
		} while ( $( "#carouselPlus .carousel-inner" ).children( ".carousel-grid" ).length );
	} else {
		do {
			$( "#carouselPlus .carousel-inner" ).children( ".carousel-grid:lt(1)" ).wrapAll( "<div class=\"carousel-item\"><div class=\"row\"></div></div>" );
			$( "#carouselPlus .carousel-inner .carousel-item:first" ).addClass("active");
		} while ( $( "#carouselPlus .carousel-inner" ).children( ".carousel-grid" ).length);
	}
}
$(window).on( "load resize", function() {
	$.when(
		$( "#carouselPlus .carousel-inner" ).replaceWith( $origin ),
		multiCarousel()
	).done(function() {
		$( ".multi-carousel" ).animate({opacity: "1"}, 1000);
	});
});
</script>