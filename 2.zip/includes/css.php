
 <link rel="Shortcut Icon" href="img/favicon.png" />
    <!-- Fonts -->
    <link href="fonts/cloudicon/cloudicon.css" rel="stylesheet" media="none" onload="if(media!='all')media='all'">
    <link href="fonts/fontawesome/css/all.css" rel="stylesheet" media="none" onload="if(media!='all')media='all'">
    <link href="fonts/opensans/opensans.css" rel="stylesheet" media="none" onload="if(media!='all')media='all'">
    <!-- CSS styles -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet" media="none" onload="if(media!='all')media='all'">
    <link href="css/swiper.min.css" rel="stylesheet" media="none" onload="if(media!='all')media='all'">
    <link href="css/animate.min.css" rel="stylesheet" media="none" onload="if(media!='all')media='all'">
    <link href="css/filter.css" rel="stylesheet">
    <link href="css/style.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/mycustom.css" rel="stylesheet">
    <!-- Custom color styles -->
    <link href="css/colors/pink.css" rel="stylesheet" title="pink" media="none" onload="if(media!='all')media='all'"/>
    <link href="css/colors/blue.css" rel="stylesheet" title="blue" media="none" onload="if(media!='all')media='all'"/>
    <link href="css/colors/green.css" rel="stylesheet" title="green" media="none" onload="if(media!='all')media='all'"/>
<style>
#circle {
      width: 300px;
      height: 300px;
      border-radius: 300px;
	  background: red;
	  border: 150px solid #BADA55;
	  animation:
      }
</style>