How to define a new suite?
==========================

To define a new suite it is needed to create a suite configuration file in a one of ``cli``/``domain``/``ui`` directory inside  ``src/Sylius/Behat/Resources/config/suites``.
Then register that file in ``src/Sylius/Behat/Resources/config/suites.yml``.
