.. rst-class:: outdated

Zone Types
==========

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

There are three zone types available by default:

+------------------+----------+
| Related constant | Type     |
+==================+==========+
| TYPE_COUNTRY     | country  |
+------------------+----------+
| TYPE_PROVINCE    | province |
+------------------+----------+
| TYPE_ZONE        | zone     |
+------------------+----------+

.. note::

   All of the above types are constant fields in the :ref:`component_addressing_model_zone-interface`.
