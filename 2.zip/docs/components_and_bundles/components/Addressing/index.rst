.. rst-class:: outdated

Addressing
==========

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Sylius Addressing component for PHP E-Commerce applications which
provides you with basic Address, Country, Province and Zone models.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   models
   interfaces
   zone_types

Learn more
----------

* :doc:`Addresses in the Sylius platform </book/customers/addresses/index>` - concept documentation
