.. rst-class:: outdated

Taxation
========

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Tax rates and tax classification for PHP applications. You can define different tax categories and match them to objects.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   models
   interfaces

Learn more
----------

* :doc:`Taxation in the Sylius platform </book/orders/taxation>` - concept documentation
