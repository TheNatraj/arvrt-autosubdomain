.. rst-class:: outdated

Inventory
=========

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Inventory management for PHP applications.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   models
   interfaces
   state_machine

Learn more
----------

* :doc:`Inventory in the Sylius platform </book/products/inventory>` - concept documentation
