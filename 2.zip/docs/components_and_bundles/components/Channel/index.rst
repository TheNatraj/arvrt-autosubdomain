.. rst-class:: outdated

Channel
=======

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Sale channels management implementation in PHP.

.. toctree::
   :maxdepth: 2

   installation
   models
   interfaces

Learn more
----------

* :doc:`Channels in the Sylius platform </book/configuration/channels>` - concept documentation
