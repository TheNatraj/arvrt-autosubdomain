.. rst-class:: outdated

SyliusProductBundle
===================

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

.. toctree::
   :maxdepth: 1
   :numbered:

   installation
   product
   forms
   summary

Learn more
----------

* :doc:`Products in the Sylius platform </book/products/index>` - concept documentation
