.. rst-class:: outdated

SyliusTaxonomyBundle
====================

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Flexible categorization system for Symfony applications.

.. toctree::
   :numbered:

   installation
   taxon
   categorization
   summary

Learn more
----------

* :doc:`Taxons in the Sylius platform </book/products/taxons>` - concept documentation
