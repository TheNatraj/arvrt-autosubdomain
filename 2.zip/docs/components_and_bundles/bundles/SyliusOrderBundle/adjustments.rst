.. rst-class:: outdated

The Adjustments
===============

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Adjustments are based on simple but powerful idea inspired by `Spree adjustments <http://guides.spreecommerce.org/developer/adjustments.html>`_.
They serve as foundation for any tax, shipping and discounts systems.

Adjustment model
----------------

.. note::

    To be written. Learn more in :doc:`the Book </book/orders/adjustments>`.
