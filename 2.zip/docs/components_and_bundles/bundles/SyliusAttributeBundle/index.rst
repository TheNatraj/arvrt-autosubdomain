.. rst-class:: outdated

SyliusAttributeBundle
=====================

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

This bundle provides easy integration of the :doc:`Sylius Attribute component </components_and_bundles/components/Attribute/index>`
with any Symfony full-stack application.

Sylius uses this bundle internally for its product catalog to manage the different attributes that are specific to each
product.


.. toctree::
    :maxdepth: 1
    :numbered:

    installation
    configuration

Learn more
----------

* :doc:`Attributes in the Sylius platform </book/products/attributes>` - concept documentation
