.. rst-class:: outdated

SyliusUserBundle
================

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

A solution for user management system inside of a Symfony application.

.. toctree::
   :numbered:

   installation
   summary

Learn more
----------

* :doc:`Users & Customers in the Sylius platform </book/customers/index>` - concept documentation
