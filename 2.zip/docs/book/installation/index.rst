Installation
============

The process of installing Sylius together with the requirements to run it efficiently.

.. toctree::
    :hidden:

    requirements
    installation
    sylius_plus_installation
    upgrading
    sylius_plus_upgrading

.. include:: /book/installation/map.rst.inc
