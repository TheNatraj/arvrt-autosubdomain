Organization
============

.. toctree::
    :hidden:

    release-cycle
    backward-compatibility-promise
    team

.. include:: /book/organization/map.rst.inc
