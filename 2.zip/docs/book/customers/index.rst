Customers
=========

This chapter will tell you more about the way Sylius handles users, customers and admins.
There is also a subchapter dedicated to addresses of your customers.

.. toctree::
    :hidden:

    customer_and_shopuser
    customer_pools
    admin_user
    addresses/index

.. include:: /book/customers/map.rst.inc
