Contributing Code
=================

.. toctree::
    :hidden:

    patches
    security
    standards
    license

.. include:: /book/contributing/code/map.rst.inc
