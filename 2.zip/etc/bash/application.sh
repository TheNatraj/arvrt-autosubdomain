#!/usr/bin/env bash

# Source nvm.sh to make the node command available
run_command "source ~/.nvm/nvm.sh"
